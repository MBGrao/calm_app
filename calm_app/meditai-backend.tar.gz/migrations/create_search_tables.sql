-- Create search_history table
CREATE TABLE IF NOT EXISTS search_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    query VARCHAR(255) NOT NULL,
    result_count INTEGER DEFAULT 0,
    filters JSONB DEFAULT '{}',
    user_agent VARCHAR(500),
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create search_analytics table
CREATE TABLE IF NOT EXISTS search_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    query VARCHAR(255) NOT NULL,
    result_count INTEGER DEFAULT 0,
    click_count INTEGER DEFAULT 0,
    avg_click_position FLOAT DEFAULT 0,
    search_count INTEGER DEFAULT 1,
    filters JSONB DEFAULT '{}',
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for search_history
CREATE INDEX IF NOT EXISTS idx_search_history_user_id ON search_history(user_id);
CREATE INDEX IF NOT EXISTS idx_search_history_query ON search_history(query);
CREATE INDEX IF NOT EXISTS idx_search_history_created_at ON search_history(created_at);
CREATE INDEX IF NOT EXISTS idx_search_history_user_query ON search_history(user_id, query);

-- Create indexes for search_analytics
CREATE INDEX IF NOT EXISTS idx_search_analytics_query ON search_analytics(query);
CREATE INDEX IF NOT EXISTS idx_search_analytics_category ON search_analytics(category);
CREATE INDEX IF NOT EXISTS idx_search_analytics_created_at ON search_analytics(created_at);
CREATE INDEX IF NOT EXISTS idx_search_analytics_search_count ON search_analytics(search_count DESC);
CREATE INDEX IF NOT EXISTS idx_search_analytics_click_count ON search_analytics(click_count DESC);

-- Create unique constraint on search_analytics query
CREATE UNIQUE INDEX IF NOT EXISTS idx_search_analytics_unique_query ON search_analytics(query);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_search_history_updated_at 
    BEFORE UPDATE ON search_history 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_search_analytics_updated_at 
    BEFORE UPDATE ON search_analytics 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Create function to calculate search relevance score
CREATE OR REPLACE FUNCTION calculate_search_relevance(search_term TEXT, content_title TEXT, content_description TEXT)
RETURNS INTEGER AS $$
BEGIN
    -- Exact title match gets highest score
    IF LOWER(content_title) = LOWER(search_term) THEN
        RETURN 100;
    -- Title starts with search term
    ELSIF LOWER(content_title) LIKE LOWER(search_term || '%') THEN
        RETURN 80;
    -- Title contains search term
    ELSIF LOWER(content_title) LIKE LOWER('%' || search_term || '%') THEN
        RETURN 60;
    -- Description contains search term
    ELSIF LOWER(content_description) LIKE LOWER('%' || search_term || '%') THEN
        RETURN 40;
    ELSE
        RETURN 0;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Create function to get trending searches
CREATE OR REPLACE FUNCTION get_trending_searches(days_back INTEGER DEFAULT 7, result_limit INTEGER DEFAULT 10)
RETURNS TABLE(query_text TEXT, search_frequency BIGINT) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sa.query::TEXT,
        COUNT(*)::BIGINT as search_frequency
    FROM search_analytics sa
    WHERE sa.created_at >= CURRENT_DATE - INTERVAL '1 day' * days_back
    GROUP BY sa.query
    ORDER BY search_frequency DESC
    LIMIT result_limit;
END;
$$ LANGUAGE plpgsql;

-- Create function to get search suggestions
CREATE OR REPLACE FUNCTION get_search_suggestions(search_term TEXT, suggestion_limit INTEGER DEFAULT 10)
RETURNS TABLE(suggestion_text TEXT, suggestion_type TEXT, relevance_score INTEGER) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.title::TEXT as suggestion_text,
        'content'::TEXT as suggestion_type,
        calculate_search_relevance(search_term, c.title, c.description) as relevance_score
    FROM content c
    WHERE 
        LOWER(c.title) LIKE LOWER('%' || search_term || '%') OR
        LOWER(c.subtitle) LIKE LOWER('%' || search_term || '%') OR
        LOWER(c.description) LIKE LOWER('%' || search_term || '%')
    ORDER BY relevance_score DESC, c.play_count DESC
    LIMIT suggestion_limit;
END;
$$ LANGUAGE plpgsql;

-- Insert sample search analytics data
INSERT INTO search_analytics (query, result_count, search_count, click_count, avg_click_position, category) VALUES
('meditation', 15, 45, 32, 2.1, 'meditation'),
('sleep', 8, 28, 22, 1.8, 'sleep'),
('anxiety', 12, 33, 25, 2.3, 'meditation'),
('breathing', 6, 18, 14, 1.9, 'breathing'),
('relaxation', 10, 25, 19, 2.0, 'relaxation'),
('stress relief', 9, 22, 17, 2.2, 'meditation'),
('mindfulness', 7, 20, 15, 1.7, 'meditation'),
('deep sleep', 5, 15, 12, 1.6, 'sleep'),
('focus', 8, 19, 16, 2.1, 'meditation'),
('calm', 11, 30, 24, 1.9, 'relaxation')
ON CONFLICT (query) DO NOTHING;

-- Create view for search performance metrics
CREATE OR REPLACE VIEW search_performance_metrics AS
SELECT 
    sa.query,
    sa.search_count,
    sa.click_count,
    sa.result_count,
    ROUND((sa.click_count::FLOAT / sa.search_count) * 100, 2) as click_through_rate,
    sa.avg_click_position,
    sa.category,
    sa.created_at,
    sa.updated_at
FROM search_analytics sa
ORDER BY sa.search_count DESC;

-- Create view for user search patterns
CREATE OR REPLACE VIEW user_search_patterns AS
SELECT 
    sh.user_id,
    u.first_name,
    u.last_name,
    sh.query,
    sh.result_count,
    sh.created_at,
    EXTRACT(DOW FROM sh.created_at) as day_of_week,
    EXTRACT(HOUR FROM sh.created_at) as hour_of_day
FROM search_history sh
JOIN users u ON sh.user_id = u.id
ORDER BY sh.created_at DESC;

-- Grant permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON search_history TO postgres;
GRANT SELECT, INSERT, UPDATE, DELETE ON search_analytics TO postgres;
GRANT SELECT ON search_performance_metrics TO postgres;
GRANT SELECT ON user_search_patterns TO postgres;

-- Create comments for documentation
COMMENT ON TABLE search_history IS 'Stores user search queries and metadata';
COMMENT ON TABLE search_analytics IS 'Stores search performance analytics and click tracking';
COMMENT ON VIEW search_performance_metrics IS 'View for analyzing search performance metrics';
COMMENT ON VIEW user_search_patterns IS 'View for analyzing user search behavior patterns'; 