#!/bin/bash

# MeditAi Backend Deployment Script
# VPS: 168.231.66.116

echo "🚀 Starting MeditAi Backend Deployment..."

# Set variables
VPS_IP="168.231.66.116"
APP_NAME="meditai-backend"
APP_DIR="/opt/meditai-backend"
SERVICE_NAME="meditai-backend"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if SSH key is available
if [ ! -f ~/.ssh/id_rsa ]; then
    print_error "SSH key not found. Please ensure your SSH key is set up."
    exit 1
fi

print_status "Connecting to VPS at $VPS_IP..."

# Create deployment package
print_status "Creating deployment package..."
tar -czf meditai-backend.tar.gz \
    --exclude='node_modules' \
    --exclude='.git' \
    --exclude='*.log' \
    --exclude='uploads/*' \
    --exclude='.env' \
    .

# Upload to VPS
print_status "Uploading to VPS..."
scp meditai-backend.tar.gz root@$VPS_IP:/tmp/

# Deploy on VPS
print_status "Deploying on VPS..."
ssh root@$VPS_IP << 'ENDSSH'
    set -e
    
    echo "📦 Installing dependencies and setting up MeditAi Backend..."
    
    # Create app directory
    mkdir -p /opt/meditai-backend
    cd /opt/meditai-backend
    
    # Extract deployment package
    tar -xzf /tmp/meditai-backend.tar.gz
    rm /tmp/meditai-backend.tar.gz
    
    # Copy production environment
    cp env.production .env
    
    # Install dependencies
    npm install --production
    
    # Create uploads directory
    mkdir -p uploads
    
    # Set permissions
    chown -R root:root /opt/meditai-backend
    chmod -R 755 /opt/meditai-backend
    
    # Create systemd service
    cat > /etc/systemd/system/meditai-backend.service << 'EOF'
[Unit]
Description=MeditAi Backend API
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/meditai-backend
Environment=NODE_ENV=production
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=meditai-backend

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd and enable service
    systemctl daemon-reload
    systemctl enable meditai-backend
    
    # Start the service
    systemctl start meditai-backend
    
    # Check service status
    sleep 5
    systemctl status meditai-backend --no-pager
    
    echo "✅ MeditAi Backend deployment completed!"
    echo "🌐 Service URL: http://168.231.66.116:3000"
    echo "🔗 Health Check: http://168.231.66.116:3000/health"
    echo "📚 API Docs: http://168.231.66.116:3000/api/v1"
ENDSSH

# Clean up local files
rm -f meditai-backend.tar.gz

print_status "Deployment completed successfully!"
print_status "Backend is now running at: http://168.231.66.116:3000"
print_status "You can test the API endpoints now."
