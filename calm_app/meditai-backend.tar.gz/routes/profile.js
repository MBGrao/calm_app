const express = require('express');
const router = express.Router();
const { getValidationRules } = require('../middleware/validation');
const { authenticateToken, requireEmailVerification } = require('../middleware/auth');
const User = require('../models/User');
const bcrypt = require('bcryptjs');

// @route   GET /api/v1/profile
// @desc    Get user profile
// @access  Private
router.get('/', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    res.json({
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      error: 'Failed to get profile',
      message: 'An error occurred while fetching profile'
    });
  }
});

// @route   PUT /api/v1/profile
// @desc    Update user profile
// @access  Private
router.put('/', authenticateToken, getValidationRules('updateProfile'), async (req, res) => {
  try {
    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    // Update user profile
    await user.update(req.body);

    res.json({
      message: 'Profile updated successfully',
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      error: 'Failed to update profile',
      message: 'An error occurred while updating profile'
    });
  }
});

// @route   PUT /api/v1/profile/change-password
// @desc    Change user password
// @access  Private
router.put('/change-password', authenticateToken, getValidationRules('changePassword'), async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);
    if (!isCurrentPasswordValid) {
      return res.status(400).json({
        error: 'Password change failed',
        message: 'Current password is incorrect'
      });
    }

    // Update password
    await user.update({ password: newPassword });

    res.json({
      message: 'Password changed successfully'
    });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({
      error: 'Failed to change password',
      message: 'An error occurred while changing password'
    });
  }
});

// @route   PUT /api/v1/profile/privacy-policy
// @desc    Accept privacy policy
// @access  Private
router.put('/privacy-policy', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    await user.update({
      acceptPrivacyPolicy: true,
      privacyPolicyAcceptedAt: new Date()
    });

    res.json({
      message: 'Privacy policy accepted successfully',
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Accept privacy policy error:', error);
    res.status(500).json({
      error: 'Failed to accept privacy policy',
      message: 'An error occurred while accepting privacy policy'
    });
  }
});

// @route   PUT /api/v1/profile/terms-of-service
// @desc    Accept terms of service
// @access  Private
router.put('/terms-of-service', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    await user.update({
      acceptTermsOfService: true,
      termsOfServiceAcceptedAt: new Date()
    });

    res.json({
      message: 'Terms of service accepted successfully',
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Accept terms of service error:', error);
    res.status(500).json({
      error: 'Failed to accept terms of service',
      message: 'An error occurred while accepting terms of service'
    });
  }
});

// @route   PUT /api/v1/profile/goals
// @desc    Update user goals
// @access  Private
router.put('/goals', authenticateToken, async (req, res) => {
  try {
    const { goals } = req.body;

    if (!Array.isArray(goals)) {
      return res.status(400).json({
        error: 'Invalid goals format',
        message: 'Goals must be an array'
      });
    }

    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    await user.update({ goals });

    res.json({
      message: 'Goals updated successfully',
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Update goals error:', error);
    res.status(500).json({
      error: 'Failed to update goals',
      message: 'An error occurred while updating goals'
    });
  }
});

// @route   PUT /api/v1/profile/preferences
// @desc    Update user preferences
// @access  Private
router.put('/preferences', authenticateToken, async (req, res) => {
  try {
    const { preferences } = req.body;

    if (typeof preferences !== 'object') {
      return res.status(400).json({
        error: 'Invalid preferences format',
        message: 'Preferences must be an object'
      });
    }

    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    // Merge with existing preferences
    const updatedPreferences = { ...user.preferences, ...preferences };
    await user.update({ preferences: updatedPreferences });

    res.json({
      message: 'Preferences updated successfully',
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Update preferences error:', error);
    res.status(500).json({
      error: 'Failed to update preferences',
      message: 'An error occurred while updating preferences'
    });
  }
});

// @route   DELETE /api/v1/profile
// @desc    Delete user account
// @access  Private
router.delete('/', authenticateToken, async (req, res) => {
  try {
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({
        error: 'Password required',
        message: 'Please provide your password to confirm account deletion'
      });
    }

    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(400).json({
        error: 'Account deletion failed',
        message: 'Password is incorrect'
      });
    }

    // Soft delete - mark as inactive
    await user.update({ isActive: false });

    res.json({
      message: 'Account deleted successfully'
    });
  } catch (error) {
    console.error('Delete account error:', error);
    res.status(500).json({
      error: 'Failed to delete account',
      message: 'An error occurred while deleting account'
    });
  }
});

// @route   GET /api/v1/profile/stats
// @desc    Get user statistics
// @access  Private
router.get('/stats', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User profile not found'
      });
    }

    // Calculate account age
    const accountAge = Math.floor((new Date() - new Date(user.createdAt)) / (1000 * 60 * 60 * 24));

    const stats = {
      accountAge: accountAge,
      isEmailVerified: user.isEmailVerified,
      acceptPrivacyPolicy: user.acceptPrivacyPolicy,
      acceptTermsOfService: user.acceptTermsOfService,
      subscriptionStatus: user.subscriptionStatus,
      lastLoginAt: user.lastLoginAt,
      goals: user.goals || [],
      preferences: user.preferences || {}
    };

    res.json({
      stats
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({
      error: 'Failed to get stats',
      message: 'An error occurred while fetching stats'
    });
  }
});

module.exports = router; 