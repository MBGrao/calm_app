const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { validateContent } = require('../middleware/validation');
const Content = require('../models/Content');
const UserProgress = require('../models/UserProgress');
const { Op } = require('sequelize');

// Get all content with pagination and filtering
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      category,
      search,
      isPremium,
      minDuration,
      maxDuration,
      sortBy = 'created_at',
      sortOrder = 'DESC',
      tags,
      author
    } = req.query;

    const offset = (page - 1) * limit;
    const whereClause = {};

    // Apply filters
    if (category) {
      whereClause.category = { [Op.iLike]: `%${category}%` };
    }

    if (search) {
      whereClause[Op.or] = [
        { title: { [Op.iLike]: `%${search}%` } },
        { description: { [Op.iLike]: `%${search}%` } },
        { subtitle: { [Op.iLike]: `%${search}%` } },
        { author: { [Op.iLike]: `%${search}%` } },
        { tags: { [Op.overlap]: [search] } }
      ];
    }

    if (isPremium !== undefined) {
      whereClause.isPremium = isPremium === 'true';
    }

    if (minDuration || maxDuration) {
      whereClause.duration = {};
      if (minDuration) whereClause.duration[Op.gte] = parseInt(minDuration);
      if (maxDuration) whereClause.duration[Op.lte] = parseInt(maxDuration);
    }

    if (tags) {
      const tagArray = Array.isArray(tags) ? tags : [tags];
      whereClause.tags = { [Op.overlap]: tagArray };
    }

    if (author) {
      whereClause.author = { [Op.iLike]: `%${author}%` };
    }

    // Validate sort parameters
    const allowedSortFields = ['created_at', 'updated_at', 'title', 'duration', 'rating', 'playCount'];
    const allowedSortOrders = ['ASC', 'DESC'];
    
    const finalSortBy = allowedSortFields.includes(sortBy) ? sortBy : 'created_at';
    const finalSortOrder = allowedSortOrders.includes(sortOrder.toUpperCase()) ? sortOrder.toUpperCase() : 'DESC';

    // Get total count
    const total = await Content.count({ where: whereClause });

    // Get content
    const content = await Content.findAll({
      where: whereClause,
      order: [[finalSortBy, finalSortOrder]],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      content: content,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        totalPages: Math.ceil(total / limit),
        hasNextPage: parseInt(page) < Math.ceil(total / limit),
        hasPrevPage: parseInt(page) > 1
      }
    });

  } catch (error) {
    console.error('Error fetching content:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch content',
      error: error.message
    });
  }
});

// Get content by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const content = await Content.findByPk(id);

    if (!content) {
      return res.status(404).json({
        success: false,
        message: 'Content not found'
      });
    }

    // Increment play count
    await content.increment('playCount');

    res.json({
      success: true,
      content: content
    });

  } catch (error) {
    console.error('Error fetching content by ID:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch content',
      error: error.message
    });
  }
});

// Search content
router.get('/search', async (req, res) => {
  try {
    const {
      q,
      category,
      duration,
      isPremium,
      page = 1,
      limit = 20,
      sortBy = 'playCount',
      sortOrder = 'DESC'
    } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        message: 'Search query is required'
      });
    }

    const offset = (page - 1) * limit;
    const whereClause = {
      [Op.or]: [
        { title: { [Op.iLike]: `%${q}%` } },
        { description: { [Op.iLike]: `%${q}%` } },
        { subtitle: { [Op.iLike]: `%${q}%` } },
        { author: { [Op.iLike]: `%${q}%` } },
        { tags: { [Op.overlap]: [q] } }
      ]
    };

    // Apply additional filters
    if (category) {
      whereClause.category = { [Op.iLike]: `%${category}%` };
    }

    if (duration) {
      whereClause.duration = { [Op.lte]: parseInt(duration) };
    }

    if (isPremium !== undefined) {
      whereClause.isPremium = isPremium === 'true';
    }

    const total = await Content.count({ where: whereClause });
    const content = await Content.findAll({
      where: whereClause,
      order: [[sortBy, sortOrder.toUpperCase()]],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      content: content,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error searching content:', error);
    res.status(500).json({
      success: false,
      message: 'Search failed',
      error: error.message
    });
  }
});

// Get content by category
router.get('/category/:category', async (req, res) => {
  try {
    const { category } = req.params;
    const { page = 1, limit = 20, sortBy = 'created_at', sortOrder = 'DESC' } = req.query;
    const offset = (page - 1) * limit;

    const whereClause = {
      category: { [Op.iLike]: `%${category}%` }
    };

    const total = await Content.count({ where: whereClause });
    const content = await Content.findAll({
      where: whereClause,
      order: [[sortBy, sortOrder.toUpperCase()]],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      content: content,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching content by category:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch category content',
      error: error.message
    });
  }
});

// Get popular content
router.get('/popular', async (req, res) => {
  try {
    const { limit = 20, page = 1 } = req.query;
    const offset = (page - 1) * limit;

    const total = await Content.count();
    const content = await Content.findAll({
      order: [['playCount', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      content: content,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching popular content:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch popular content',
      error: error.message
    });
  }
});

// Get recommended content (requires authentication)
router.get('/recommended', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const userId = req.user.id;
    const offset = (page - 1) * limit;

    // Get user's favorite categories based on their progress
    const userProgress = await UserProgress.findAll({
      where: { userId },
      include: [{ model: Content, as: 'content', attributes: ['category'] }],
      order: [['created_at', 'DESC']],
      limit: 50
    });

    const categoryCounts = {};
    userProgress.forEach(progress => {
      const category = progress.content?.category;
      if (category) {
        categoryCounts[category] = (categoryCounts[category] || 0) + 1;
      }
    });

    // Get top 3 favorite categories
    const favoriteCategories = Object.entries(categoryCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([category]) => category);

    let whereClause = {};
    if (favoriteCategories.length > 0) {
      whereClause.category = { [Op.in]: favoriteCategories };
    }

    const total = await Content.count({ where: whereClause });
    const content = await Content.findAll({
      where: whereClause,
      order: [['playCount', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      content: content,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching recommended content:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recommendations',
      error: error.message
    });
  }
});

// Get categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await Content.findAll({
      attributes: [
        'category',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['category'],
      order: [[Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'DESC']]
    });

    const formattedCategories = categories.map(cat => ({
      name: cat.category,
      count: parseInt(cat.getDataValue('count')),
      displayName: getCategoryDisplayName(cat.category)
    }));

    res.json({
      success: true,
      categories: formattedCategories
    });

  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch categories',
      error: error.message
    });
  }
});

// Get content statistics
router.get('/stats', async (req, res) => {
  try {
    const totalContent = await Content.count();
    const totalPlayCount = await Content.sum('playCount') || 0;
    const avgRating = await Content.findAll({
      attributes: [[Content.sequelize.fn('AVG', Content.sequelize.col('rating')), 'avgRating']]
    });
    
    const categoryStats = await Content.findAll({
      attributes: [
        'category',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['category'],
      order: [[Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'DESC']],
      limit: 5
    });

    res.json({
      success: true,
      stats: {
        totalContent,
        totalPlayCount,
        avgRating: parseFloat(avgRating[0]?.getDataValue('avgRating') || 0).toFixed(2),
        topCategories: categoryStats.map(cat => ({
          category: cat.category,
          count: parseInt(cat.getDataValue('count'))
        }))
      }
    });

  } catch (error) {
    console.error('Error fetching content stats:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch content stats',
      error: error.message
    });
  }
});

// Create new content (admin only)
router.post('/', authenticateToken, validateContent, async (req, res) => {
  try {
    const contentData = req.body;
    const newContent = await Content.create(contentData);

    res.status(201).json({
      success: true,
      content: newContent,
      message: 'Content created successfully'
    });

  } catch (error) {
    console.error('Error creating content:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create content',
      error: error.message
    });
  }
});

// Update content (admin only)
router.put('/:id', authenticateToken, validateContent, async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    const content = await Content.findByPk(id);
    if (!content) {
      return res.status(404).json({
        success: false,
        message: 'Content not found'
      });
    }

    await content.update(updateData);

    res.json({
      success: true,
      content: content,
      message: 'Content updated successfully'
    });

  } catch (error) {
    console.error('Error updating content:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update content',
      error: error.message
    });
  }
});

// Delete content (admin only)
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const content = await Content.findByPk(id);

    if (!content) {
      return res.status(404).json({
        success: false,
        message: 'Content not found'
      });
    }

    await content.destroy();

    res.json({
      success: true,
      message: 'Content deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting content:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete content',
      error: error.message
    });
  }
});

// Helper function to get category display names
function getCategoryDisplayName(category) {
  const displayNames = {
    'meditation': 'Meditation',
    'sleep': 'Sleep Stories',
    'breathing': 'Breathing Exercises',
    'relaxation': 'Relaxation',
    'music': 'Music',
    'nature': 'Nature Sounds'
  };
  return displayNames[category] || category;
}

module.exports = router; 