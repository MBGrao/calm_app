const express = require('express');
const router = express.Router();
const { getValidationRules } = require('../middleware/validation');
const { authenticateToken, rateLimitLogin } = require('../middleware/auth');
const { generateTokenPair, generateEmailVerificationToken, generatePasswordResetToken, hashToken } = require('../utils/jwt');
const User = require('../models/User');
const RefreshToken = require('../models/RefreshToken');
const crypto = require('crypto');

// @route   POST /api/v1/auth/signup
// @desc    Register a new user
// @access  Public
router.post('/signup', getValidationRules('signup'), async (req, res) => {
  try {
    console.log('Signup request body:', req.body);
    const { email, password, firstName, lastName, acceptPrivacyPolicy, acceptTermsOfService, referralSource, goals } = req.body;

    // Check if user already exists
    console.log('Checking if user exists with email:', email);
    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      console.log('User already exists:', existingUser.email);
      return res.status(400).json({
        error: 'Registration failed',
        message: 'User with this email already exists'
      });
    }
    console.log('User does not exist, proceeding with creation');

    // Create new user
    const user = await User.create({
      email: email.toLowerCase(),
      password,
      firstName,
      lastName,
      acceptPrivacyPolicy: acceptPrivacyPolicy || false,
      acceptTermsOfService: acceptTermsOfService || false,
      referralSource,
      goals,
      isEmailVerified: true, // Skip email verification
      privacyPolicyAcceptedAt: acceptPrivacyPolicy ? new Date() : null,
      termsOfServiceAcceptedAt: acceptTermsOfService ? new Date() : null
    });

    // Generate tokens
    const { accessToken, refreshToken } = generateTokenPair(user.id, user.email);

    // Save refresh token
    const refreshTokenDoc = await RefreshToken.createToken(user.id);

    // Update user's last login
    await user.update({ lastLoginAt: new Date() });

    res.status(201).json({
      message: 'User registered successfully',
      accessToken,
      refreshToken,
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Signup error:', error);
    console.error('Error stack:', error.stack);
    res.status(500).json({
      error: 'Registration failed',
      message: 'An error occurred during registration'
    });
  }
});

// @route   POST /api/v1/auth/signin
// @desc    Authenticate user & get token
// @access  Public
router.post('/signin', getValidationRules('signin'), async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user by email
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Invalid email or password'
      });
    }

    // Check if account is locked
    if (user.lockUntil && user.lockUntil > new Date()) {
      return res.status(423).json({
        error: 'Account locked',
        message: 'Your account has been temporarily locked due to multiple failed login attempts'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Account is deactivated'
      });
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      // Increment login attempts
      const newLoginAttempts = user.loginAttempts + 1;
      let lockUntil = null;
      
      if (newLoginAttempts >= 5) {
        lockUntil = new Date();
        lockUntil.setMinutes(lockUntil.getMinutes() + 15); // Lock for 15 minutes
      }

      await user.update({
        loginAttempts: newLoginAttempts,
        lockUntil
      });

      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Invalid email or password'
      });
    }

    // Reset login attempts on successful login
    await user.update({
      loginAttempts: 0,
      lockUntil: null,
      lastLoginAt: new Date()
    });

    // Generate tokens
    const { accessToken, refreshToken } = generateTokenPair(user.id, user.email);

    // Save refresh token
    const refreshTokenDoc = await RefreshToken.createToken(user.id);

    res.json({
      message: 'Login successful',
      accessToken,
      refreshToken,
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Signin error:', error);
    res.status(500).json({
      error: 'Authentication failed',
      message: 'An error occurred during authentication'
    });
  }
});

// @route   POST /api/v1/auth/refresh
// @desc    Refresh access token
// @access  Public
router.post('/refresh', getValidationRules('refreshToken'), async (req, res) => {
  try {
    const { refreshToken } = req.body;

    // Find refresh token in database
    const tokenDoc = await RefreshToken.findByToken(refreshToken);
    if (!tokenDoc || !tokenDoc.isValid()) {
      return res.status(401).json({
        error: 'Token refresh failed',
        message: 'Invalid or expired refresh token'
      });
    }

    // Get user
    const user = await User.findByPk(tokenDoc.userId);
    if (!user || !user.isActive) {
      return res.status(401).json({
        error: 'Token refresh failed',
        message: 'User not found or inactive'
      });
    }

    // Generate new tokens
    const { accessToken, refreshToken: newRefreshToken } = generateTokenPair(user.id, user.email);

    // Revoke old refresh token
    await RefreshToken.revokeToken(refreshToken);

    // Save new refresh token
    const newRefreshTokenDoc = await RefreshToken.createToken(user.id);

    res.json({
      message: 'Token refreshed successfully',
      accessToken,
      refreshToken: newRefreshToken
    });

  } catch (error) {
    console.error('Token refresh error:', error);
    res.status(500).json({
      error: 'Token refresh failed',
      message: 'An error occurred while refreshing token'
    });
  }
});

// @route   POST /api/v1/auth/logout
// @desc    Logout user (revoke refresh token)
// @access  Private
router.post('/logout', authenticateToken, async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (refreshToken) {
      // Revoke the specific refresh token
      await RefreshToken.revokeToken(refreshToken);
    } else {
      // Revoke all refresh tokens for the user
      await RefreshToken.revokeAllUserTokens(req.userId);
    }

    res.json({
      message: 'Logout successful'
    });

  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      error: 'Logout failed',
      message: 'An error occurred during logout'
    });
  }
});

// @route   POST /api/v1/auth/forgot-password
// @desc    Send password reset email
// @access  Public
router.post('/forgot-password', getValidationRules('forgotPassword'), async (req, res) => {
  try {
    const { email } = req.body;

    // Find user by email
    const user = await User.findByEmail(email);
    if (!user) {
      // Don't reveal if user exists or not
      return res.json({
        message: 'If an account with that email exists, a password reset link has been sent'
      });
    }

    // Generate password reset token
    const resetToken = generatePasswordResetToken();
    const hashedToken = hashToken(resetToken);

    // Set token expiration (1 hour)
    const resetExpires = new Date();
    resetExpires.setHours(resetExpires.getHours() + 1);

    // Save token to user
    await user.update({
      passwordResetToken: hashedToken,
      passwordResetExpires: resetExpires
    });

    // TODO: Send email with reset link
    // For now, just return success
    console.log('Password reset token:', resetToken);

    res.json({
      message: 'If an account with that email exists, a password reset link has been sent'
    });

  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({
      error: 'Password reset failed',
      message: 'An error occurred while processing password reset'
    });
  }
});

// @route   POST /api/v1/auth/reset-password
// @desc    Reset password with token
// @access  Public
router.post('/reset-password', getValidationRules('resetPassword'), async (req, res) => {
  try {
    const { token, password } = req.body;

    // Hash the provided token
    const hashedToken = hashToken(token);

    // Find user with valid reset token
    const user = await User.findOne({
      where: {
        passwordResetToken: hashedToken,
        passwordResetExpires: {
          [require('sequelize').Op.gt]: new Date()
        }
      }
    });

    if (!user) {
      return res.status(400).json({
        error: 'Password reset failed',
        message: 'Invalid or expired reset token'
      });
    }

    // Update password and clear reset token
    await user.update({
      password,
      passwordResetToken: null,
      passwordResetExpires: null,
      loginAttempts: 0,
      lockUntil: null
    });

    // Revoke all existing refresh tokens
    await RefreshToken.revokeAllUserTokens(user.id);

    res.json({
      message: 'Password reset successful'
    });

  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({
      error: 'Password reset failed',
      message: 'An error occurred while resetting password'
    });
  }
});

// @route   POST /api/v1/auth/verify-email
// @desc    Verify email with token
// @access  Public
router.post('/verify-email', getValidationRules('verifyEmail'), async (req, res) => {
  try {
    const { token } = req.body;

    // Hash the provided token
    const hashedToken = hashToken(token);

    // Find user with valid verification token
    const user = await User.findOne({
      where: {
        emailVerificationToken: hashedToken,
        emailVerificationExpires: {
          [require('sequelize').Op.gt]: new Date()
        }
      }
    });

    if (!user) {
      return res.status(400).json({
        error: 'Email verification failed',
        message: 'Invalid or expired verification token'
      });
    }

    // Mark email as verified
    await user.update({
      isEmailVerified: true,
      emailVerificationToken: null,
      emailVerificationExpires: null
    });

    res.json({
      message: 'Email verified successfully'
    });

  } catch (error) {
    console.error('Email verification error:', error);
    res.status(500).json({
      error: 'Email verification failed',
      message: 'An error occurred while verifying email'
    });
  }
});

// @route   GET /api/v1/auth/me
// @desc    Get current user
// @access  Private
router.get('/me', authenticateToken, async (req, res) => {
  try {
    res.json({
      user: req.user.toJSON()
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({
      error: 'Failed to get user',
      message: 'An error occurred while fetching user data'
    });
  }
});

module.exports = router; 