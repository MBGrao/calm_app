const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const UserProgress = require('../models/UserProgress');
const Content = require('../models/Content');
const { Op } = require('sequelize');

// Record a meditation session
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { contentId, duration, metadata } = req.body;
    const userId = req.user.id;

    // Validate required fields
    if (!contentId || !duration) {
      return res.status(400).json({
        success: false,
        message: 'Content ID and duration are required'
      });
    }

    // Verify content exists
    const content = await Content.findByPk(contentId);
    if (!content) {
      return res.status(404).json({
        success: false,
        message: 'Content not found'
      });
    }

    // Create progress record
    const progress = await UserProgress.create({
      userId,
      contentId,
      duration: parseInt(duration),
      completedAt: new Date(),
      metadata: metadata || {}
    });

    // Update content play count
    await content.increment('playCount');

    res.status(201).json({
      success: true,
      progress: progress,
      message: 'Session recorded successfully'
    });

  } catch (error) {
    console.error('Error recording session:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to record session',
      error: error.message
    });
  }
});

// Alias for session endpoint (same as POST /)
router.post('/session', authenticateToken, async (req, res) => {
  try {
    const { contentId, duration, metadata } = req.body;
    const userId = req.user.id;

    // Validate required fields
    if (!contentId || !duration) {
      return res.status(400).json({
        success: false,
        message: 'Content ID and duration are required'
      });
    }

    // Verify content exists
    const content = await Content.findByPk(contentId);
    if (!content) {
      return res.status(404).json({
        success: false,
        message: 'Content not found'
      });
    }

    // Create progress record
    const progress = await UserProgress.create({
      userId,
      contentId,
      duration: parseInt(duration),
      completedAt: new Date(),
      metadata: metadata || {}
    });

    // Update content play count
    await content.increment('playCount');

    res.status(201).json({
      success: true,
      progress: progress,
      message: 'Session recorded successfully'
    });

  } catch (error) {
    console.error('Error recording session:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to record session',
      error: error.message
    });
  }
});

// Get user statistics
router.get('/stats', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;

    const stats = await UserProgress.getUserStats(userId);
    const streak = await UserProgress.getUserStreak(userId);

    res.json({
      success: true,
      stats: {
        ...stats,
        currentStreak: streak
      }
    });

  } catch (error) {
    console.error('Error fetching user stats:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch user stats',
      error: error.message
    });
  }
});

// Get user streak
router.get('/streak', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const streak = await UserProgress.getUserStreak(userId);

    res.json({
      success: true,
      currentStreak: streak
    });

  } catch (error) {
    console.error('Error fetching user streak:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch user streak',
      error: error.message
    });
  }
});

// Get recent sessions
router.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const sessions = await UserProgress.findAll({
      where: { userId },
      include: [{
        model: Content,
        attributes: ['id', 'title', 'subtitle', 'imageUrl', 'category', 'duration']
      }],
      order: [['completedAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    const total = await UserProgress.count({ where: { userId } });

    res.json({
      success: true,
      sessions: sessions,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        totalPages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('Error fetching recent sessions:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recent sessions',
      error: error.message
    });
  }
});

// Get weekly statistics
router.get('/weekly', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const weeklyStats = await UserProgress.findAll({
      where: {
        userId,
        completedAt: {
          [Op.gte]: oneWeekAgo
        }
      },
      attributes: [
        [UserProgress.sequelize.fn('DATE', UserProgress.sequelize.col('completedAt')), 'date'],
        [UserProgress.sequelize.fn('COUNT', UserProgress.sequelize.col('id')), 'sessions'],
        [UserProgress.sequelize.fn('SUM', UserProgress.sequelize.col('duration')), 'totalMinutes']
      ],
      group: [UserProgress.sequelize.fn('DATE', UserProgress.sequelize.col('completedAt'))],
      order: [[UserProgress.sequelize.fn('DATE', UserProgress.sequelize.col('completedAt')), 'ASC']]
    });

    res.json({
      success: true,
      weeklyStats: weeklyStats
    });

  } catch (error) {
    console.error('Error fetching weekly stats:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch weekly stats',
      error: error.message
    });
  }
});

// Get monthly statistics
router.get('/monthly', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;
    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

    const monthlyStats = await UserProgress.findAll({
      where: {
        userId,
        completedAt: {
          [Op.gte]: oneMonthAgo
        }
      },
      attributes: [
        [UserProgress.sequelize.fn('DATE_TRUNC', 'week', UserProgress.sequelize.col('completedAt')), 'week'],
        [UserProgress.sequelize.fn('COUNT', UserProgress.sequelize.col('id')), 'sessions'],
        [UserProgress.sequelize.fn('SUM', UserProgress.sequelize.col('duration')), 'totalMinutes']
      ],
      group: [UserProgress.sequelize.fn('DATE_TRUNC', 'week', UserProgress.sequelize.col('completedAt'))],
      order: [[UserProgress.sequelize.fn('DATE_TRUNC', 'week', UserProgress.sequelize.col('completedAt')), 'ASC']]
    });

    res.json({
      success: true,
      monthlyStats: monthlyStats
    });

  } catch (error) {
    console.error('Error fetching monthly stats:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch monthly stats',
      error: error.message
    });
  }
});

// Get favorite categories
router.get('/favorites', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;

    const favoriteCategories = await UserProgress.findAll({
      where: { userId },
      include: [{
        model: Content,
        attributes: ['category']
      }],
      attributes: [
        [UserProgress.sequelize.col('Content.category'), 'category'],
        [UserProgress.sequelize.fn('COUNT', UserProgress.sequelize.col('UserProgress.id')), 'sessionCount'],
        [UserProgress.sequelize.fn('SUM', UserProgress.sequelize.col('UserProgress.duration')), 'totalMinutes']
      ],
      group: [UserProgress.sequelize.col('Content.category')],
      order: [[UserProgress.sequelize.fn('COUNT', UserProgress.sequelize.col('UserProgress.id')), 'DESC']],
      limit: 5
    });

    res.json({
      success: true,
      categories: favoriteCategories
    });

  } catch (error) {
    console.error('Error fetching favorite categories:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch favorite categories',
      error: error.message
    });
  }
});

// Get session by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const session = await UserProgress.findOne({
      where: { id, userId },
      include: [{
        model: Content,
        attributes: ['id', 'title', 'subtitle', 'imageUrl', 'category', 'duration', 'author']
      }]
    });

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    res.json({
      success: true,
      session: session
    });

  } catch (error) {
    console.error('Error fetching session:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch session',
      error: error.message
    });
  }
});

// Delete session
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const session = await UserProgress.findOne({
      where: { id, userId }
    });

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    await session.destroy();

    res.json({
      success: true,
      message: 'Session deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting session:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete session',
      error: error.message
    });
  }
});

module.exports = router; 