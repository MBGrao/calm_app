const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const Content = require('../models/Content');
const UserProgress = require('../models/UserProgress');
const SearchHistory = require('../models/SearchHistory');
const SearchAnalytics = require('../models/SearchAnalytics');
const { Op } = require('sequelize');

// Main search endpoint with advanced filtering and analytics
router.get('/content', async (req, res) => {
  try {
    const {
      q,
      page = 1,
      limit = 20,
      category,
      tags,
      minDuration,
      maxDuration,
      isPremium,
      author,
      minRating,
      sortBy = 'relevance',
      sortOrder = 'DESC'
    } = req.query;

    if (!q || q.trim().length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Search query must be at least 2 characters long'
      });
    }

    const offset = (page - 1) * limit;
    const whereClause = {};

    // Text search across multiple fields with improved relevance
    const searchQuery = q.trim();
    whereClause[Op.or] = [
      { title: { [Op.iLike]: `%${searchQuery}%` } },
      { description: { [Op.iLike]: `%${searchQuery}%` } },
      { subtitle: { [Op.iLike]: `%${searchQuery}%` } },
      { author: { [Op.iLike]: `%${searchQuery}%` } },
      { tags: { [Op.overlap]: [searchQuery] } }
    ];

    // Apply filters
    if (category) {
      whereClause.category = { [Op.iLike]: `%${category}%` };
    }

    if (tags) {
      const tagArray = Array.isArray(tags) ? tags : tags.split(',');
      whereClause.tags = { [Op.overlap]: tagArray };
    }

    if (minDuration || maxDuration) {
      whereClause.duration = {};
      if (minDuration) whereClause.duration[Op.gte] = parseInt(minDuration);
      if (maxDuration) whereClause.duration[Op.lte] = parseInt(maxDuration);
    }

    if (isPremium !== undefined) {
      whereClause.isPremium = isPremium === 'true';
    }

    if (author) {
      whereClause.author = { [Op.iLike]: `%${author}%` };
    }

    if (minRating) {
      whereClause.rating = { [Op.gte]: parseFloat(minRating) };
    }

    // Determine sort order with relevance scoring
    let orderClause;
    switch (sortBy) {
      case 'relevance':
        // For relevance, we'll use a combination of factors
        orderClause = [
          [Content.sequelize.literal(`
            CASE 
              WHEN title ILIKE '${searchQuery}' THEN 3
              WHEN title ILIKE '${searchQuery}%' THEN 2
              WHEN title ILIKE '%${searchQuery}%' THEN 1
              ELSE 0
            END
          `), 'DESC'],
          ['playCount', 'DESC'],
          ['rating', 'DESC']
        ];
        break;
      case 'title':
        orderClause = [['title', sortOrder.toUpperCase()]];
        break;
      case 'duration':
        orderClause = [['duration', sortOrder.toUpperCase()]];
        break;
      case 'rating':
        orderClause = [['rating', sortOrder.toUpperCase()]];
        break;
      case 'playCount':
        orderClause = [['playCount', sortOrder.toUpperCase()]];
        break;
      case 'createdAt':
        orderClause = [['createdAt', sortOrder.toUpperCase()]];
        break;
      default:
        orderClause = [['playCount', 'DESC']];
    }

    // Get total count
    const total = await Content.count({ where: whereClause });

    // Get content with relevance scoring
    const content = await Content.findAll({
      where: whereClause,
      order: orderClause,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    // Get category counts for filtering
    const categoryCounts = await Content.findAll({
      where: whereClause,
      attributes: [
        'category',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['category'],
      order: [[Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'DESC']]
    });

    // Generate suggested queries based on search results
    const suggestedQueries = generateSuggestedQueries(searchQuery, content);

    // Record search analytics
    const filters = {
      category: category || null,
      tags: tags || null,
      minDuration: minDuration || null,
      maxDuration: maxDuration || null,
      isPremium: isPremium || null,
      author: author || null,
      minRating: minRating || null,
      sortBy,
      sortOrder
    };

    await SearchAnalytics.recordSearch(searchQuery, total, filters, category);

    // Record search history if user is authenticated
    if (req.user) {
      await SearchHistory.create({
        userId: req.user.id,
        query: searchQuery,
        resultCount: total,
        filters: filters,
        userAgent: req.get('User-Agent'),
        ipAddress: req.ip
      });
    }

    res.json({
      success: true,
      content: content,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(total / limit),
      hasNextPage: parseInt(page) < Math.ceil(total / limit),
      hasPrevPage: parseInt(page) > 1,
      categoryCounts: categoryCounts.reduce((acc, cat) => {
        acc[cat.category] = parseInt(cat.getDataValue('count'));
        return acc;
      }, {}),
      suggestedQueries,
      searchTime: Date.now() // For performance tracking
    });

  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({
      success: false,
      message: 'Search failed',
      error: error.message
    });
  }
});

// Record search result click
router.post('/click', async (req, res) => {
  try {
    const { query, contentId, position } = req.body;

    if (!query || !contentId) {
      return res.status(400).json({
        success: false,
        message: 'Query and contentId are required'
      });
    }

    // Record click analytics
    await SearchAnalytics.recordClick(query, position || 1);

    // Increment content play count
    await Content.increment('playCount', { where: { id: contentId } });

    res.json({
      success: true,
      message: 'Click recorded successfully'
    });

  } catch (error) {
    console.error('Click recording error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to record click',
      error: error.message
    });
  }
});

// Get search suggestions with improved relevance
router.get('/suggestions', async (req, res) => {
  try {
    const { q } = req.query;

    if (!q || q.trim().length < 2) {
      return res.json({
        success: true,
        suggestions: []
      });
    }

    const query = q.trim();
    const suggestions = [];

    // Get content suggestions with relevance scoring
    const contentSuggestions = await Content.findAll({
      where: {
        [Op.or]: [
          { title: { [Op.iLike]: `%${query}%` } },
          { subtitle: { [Op.iLike]: `%${query}%` } },
          { description: { [Op.iLike]: `%${query}%` } }
        ]
      },
      attributes: [
        'title',
        'subtitle',
        'category',
        'playCount',
        'rating',
        [Content.sequelize.literal(`
          CASE 
            WHEN title ILIKE '${query}' THEN 3
            WHEN title ILIKE '${query}%' THEN 2
            WHEN title ILIKE '%${query}%' THEN 1
            ELSE 0
          END
        `), 'relevance']
      ],
      order: [
        [Content.sequelize.literal('relevance'), 'DESC'],
        ['playCount', 'DESC']
      ],
      limit: 5
    });

    contentSuggestions.forEach(item => {
      suggestions.push({
        query: item.title,
        type: 'content',
        subtitle: item.subtitle,
        count: null,
        relevance: item.getDataValue('relevance')
      });
    });

    // Get category suggestions
    const categorySuggestions = await Content.findAll({
      where: {
        category: { [Op.iLike]: `%${query}%` }
      },
      attributes: [
        'category',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['category'],
      limit: 3
    });

    categorySuggestions.forEach(item => {
      suggestions.push({
        query: item.category,
        type: 'category',
        subtitle: `${item.getDataValue('count')} items`,
        count: parseInt(item.getDataValue('count')),
        relevance: 2
      });
    });

    // Get author suggestions
    const authorSuggestions = await Content.findAll({
      where: {
        author: { [Op.iLike]: `%${query}%` }
      },
      attributes: [
        'author',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['author'],
      limit: 3
    });

    authorSuggestions.forEach(item => {
      suggestions.push({
        query: item.author,
        type: 'author',
        subtitle: `${item.getDataValue('count')} items`,
        count: parseInt(item.getDataValue('count')),
        relevance: 2
      });
    });

    // Get tag suggestions
    const tagSuggestions = await Content.findAll({
      where: {
        tags: { [Op.overlap]: [query] }
      },
      attributes: [
        'tags',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['tags'],
      limit: 3
    });

    tagSuggestions.forEach(item => {
      const matchingTags = item.tags.filter(tag => 
        tag.toLowerCase().includes(query.toLowerCase())
      );
      matchingTags.forEach(tag => {
        suggestions.push({
          query: tag,
          type: 'tag',
          subtitle: `${item.getDataValue('count')} items`,
          count: parseInt(item.getDataValue('count')),
          relevance: 1
        });
      });
    });

    // Remove duplicates, sort by relevance, and limit results
    const uniqueSuggestions = suggestions
      .filter((suggestion, index, self) => 
        index === self.findIndex(s => s.query === suggestion.query)
      )
      .sort((a, b) => (b.relevance || 0) - (a.relevance || 0))
      .slice(0, 10)
      .map(suggestion => {
        const { relevance, ...suggestionWithoutRelevance } = suggestion;
        return suggestionWithoutRelevance;
      });

    res.json({
      success: true,
      suggestions: uniqueSuggestions
    });

  } catch (error) {
    console.error('Suggestions error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get suggestions',
      error: error.message
    });
  }
});

// Get trending searches based on analytics
router.get('/trending', async (req, res) => {
  try {
    const { days = 7, limit = 10 } = req.query;

    // Get trending searches from analytics
    const trendingAnalytics = await SearchAnalytics.getTrendingQueries(
      parseInt(days),
      parseInt(limit)
    );

    let trendingSearches = trendingAnalytics.map(item => item.query);

    // If not enough trending searches, supplement with popular content
    if (trendingSearches.length < parseInt(limit)) {
      const popularContent = await Content.findAll({
        attributes: ['title'],
        order: [['playCount', 'DESC']],
        limit: parseInt(limit) - trendingSearches.length
      });

      const contentTitles = popularContent.map(item => item.title);
      trendingSearches = [...trendingSearches, ...contentTitles];
    }

    res.json({
      success: true,
      trending: trendingSearches.slice(0, parseInt(limit))
    });

  } catch (error) {
    console.error('Trending searches error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get trending searches',
      error: error.message
    });
  }
});

// Get user search history with pagination
router.get('/history', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const userId = req.user.id;
    const offset = (page - 1) * limit;

    const history = await SearchHistory.findAll({
      where: { userId },
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    const total = await SearchHistory.count({ where: { userId } });

    // Get unique queries from history
    const uniqueQueries = history
      .map(item => item.query)
      .filter((query, index, self) => self.indexOf(query) === index);

    res.json({
      success: true,
      history: uniqueQueries,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(total / limit)
    });

  } catch (error) {
    console.error('Search history error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get search history',
      error: error.message
    });
  }
});

// Save search query to history
router.post('/history', authenticateToken, async (req, res) => {
  try {
    const { query } = req.body;
    const userId = req.user.id;

    if (!query || query.trim().length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Invalid search query'
      });
    }

    await SearchHistory.create({
      userId,
      query: query.trim(),
      userAgent: req.get('User-Agent'),
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Search query saved'
    });

  } catch (error) {
    console.error('Save search history error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to save search query',
      error: error.message
    });
  }
});

// Clear search history
router.delete('/history', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id;

    await SearchHistory.destroy({
      where: { userId }
    });

    res.json({
      success: true,
      message: 'Search history cleared'
    });

  } catch (error) {
    console.error('Clear search history error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to clear search history',
      error: error.message
    });
  }
});

// Get comprehensive search statistics
router.get('/stats', async (req, res) => {
  try {
    const totalContent = await Content.count();
    const totalPlayCount = await Content.sum('playCount') || 0;
    const avgRating = await Content.findAll({
      attributes: [[Content.sequelize.fn('AVG', Content.sequelize.col('rating')), 'avgRating']]
    });

    // Get search analytics
    const popularQueries = await SearchAnalytics.getPopularQueries(10);
    const categoryStats = await SearchAnalytics.getCategoryStats();

    // Get content category distribution
    const contentCategoryStats = await Content.findAll({
      attributes: [
        'category',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['category'],
      order: [[Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'DESC']],
      limit: 5
    });

    res.json({
      success: true,
      stats: {
        totalContent,
        totalPlayCount,
        avgRating: parseFloat(avgRating[0]?.getDataValue('avgRating') || 0).toFixed(2),
        popularQueries: popularQueries.map(q => ({
          query: q.query,
          searchCount: q.searchCount,
          clickCount: q.clickCount,
          clickRate: q.getDataValue('clickRate')
        })),
        categoryStats: categoryStats.map(cat => ({
          category: cat.category,
          searchCount: parseInt(cat.getDataValue('searchCount')),
          avgResults: parseFloat(cat.getDataValue('avgResults') || 0).toFixed(2),
          avgClicks: parseFloat(cat.getDataValue('avgClicks') || 0).toFixed(2)
        })),
        contentCategories: contentCategoryStats.map(cat => ({
          category: cat.category,
          count: parseInt(cat.getDataValue('count'))
        }))
      }
    });

  } catch (error) {
    console.error('Search stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get search statistics',
      error: error.message
    });
  }
});

// Advanced search endpoint with enhanced filtering
router.post('/advanced', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      sortBy = 'relevance',
      sortOrder = 'DESC',
      ...filters
    } = req.body;

    const offset = (page - 1) * limit;
    const whereClause = {};

    // Apply advanced filters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== '') {
        switch (key) {
          case 'category':
            whereClause.category = { [Op.iLike]: `%${value}%` };
            break;
          case 'tags':
            const tagArray = Array.isArray(value) ? value : [value];
            whereClause.tags = { [Op.overlap]: tagArray };
            break;
          case 'minDuration':
            whereClause.duration = { ...whereClause.duration, [Op.gte]: parseInt(value) };
            break;
          case 'maxDuration':
            whereClause.duration = { ...whereClause.duration, [Op.lte]: parseInt(value) };
            break;
          case 'isPremium':
            whereClause.isPremium = value === true || value === 'true';
            break;
          case 'author':
            whereClause.author = { [Op.iLike]: `%${value}%` };
            break;
          case 'minRating':
            whereClause.rating = { [Op.gte]: parseFloat(value) };
            break;
        }
      }
    });

    // Determine sort order
    let orderClause;
    switch (sortBy) {
      case 'relevance':
        orderClause = [['playCount', sortOrder.toUpperCase()], ['rating', 'DESC']];
        break;
      case 'title':
        orderClause = [['title', sortOrder.toUpperCase()]];
        break;
      case 'duration':
        orderClause = [['duration', sortOrder.toUpperCase()]];
        break;
      case 'rating':
        orderClause = [['rating', sortOrder.toUpperCase()]];
        break;
      case 'playCount':
        orderClause = [['playCount', sortOrder.toUpperCase()]];
        break;
      case 'createdAt':
        orderClause = [['createdAt', sortOrder.toUpperCase()]];
        break;
      default:
        orderClause = [['playCount', 'DESC']];
    }

    const total = await Content.count({ where: whereClause });
    const content = await Content.findAll({
      where: whereClause,
      order: orderClause,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      content: content,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(total / limit),
      hasNextPage: parseInt(page) < Math.ceil(total / limit),
      hasPrevPage: parseInt(page) > 1
    });

  } catch (error) {
    console.error('Advanced search error:', error);
    res.status(500).json({
      success: false,
      message: 'Advanced search failed',
      error: error.message
    });
  }
});

// Helper function to generate suggested queries with improved relevance
function generateSuggestedQueries(searchQuery, content) {
  const suggestions = [];
  
  // Extract words from search query
  const words = searchQuery.toLowerCase().split(' ').filter(word => word.length > 2);
  
  // Generate variations based on content
  words.forEach(word => {
    if (word.length > 3) {
      suggestions.push(word);
      suggestions.push(word + ' meditation');
      suggestions.push(word + ' sleep');
      suggestions.push(word + ' relaxation');
    }
  });

  // Add content-based suggestions
  content.forEach(item => {
    const titleWords = item.title.toLowerCase().split(' ');
    titleWords.forEach(word => {
      if (word.length > 3 && !suggestions.includes(word)) {
        suggestions.push(word);
      }
    });

    // Add category-based suggestions
    if (item.category && !suggestions.includes(item.category)) {
      suggestions.push(item.category);
    }
  });

  // Add trending variations
  const trendingVariations = [
    'meditation',
    'sleep',
    'relaxation',
    'breathing',
    'mindfulness',
    'stress relief',
    'anxiety',
    'focus'
  ];

  trendingVariations.forEach(variation => {
    if (!suggestions.includes(variation)) {
      suggestions.push(variation);
    }
  });

  return suggestions.slice(0, 8);
}

module.exports = router; 