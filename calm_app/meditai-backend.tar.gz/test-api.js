const axios = require('axios');

const BASE_URL = 'http://localhost:3000/api/v1';

// Test data
const testUser = {
  email: 'test@example.com',
  password: 'password123',
  firstName: 'Test',
  lastName: 'User',
  acceptPrivacyPolicy: true,
  acceptTermsOfService: true
};

let accessToken = null;
let refreshToken = null;

async function testHealthCheck() {
  try {
    console.log('🏥 Testing health check...');
    const response = await axios.get('http://localhost:3000/health');
    console.log('✅ Health check passed:', response.data);
    return true;
  } catch (error) {
    console.error('❌ Health check failed:', error.message);
    return false;
  }
}

async function testUserRegistration() {
  try {
    console.log('\n📝 Testing user registration...');
    const response = await axios.post(`${BASE_URL}/auth/signup`, testUser);
    console.log('✅ User registration successful');
    
    accessToken = response.data.accessToken;
    refreshToken = response.data.refreshToken;
    
    console.log('User ID:', response.data.user.id);
    console.log('Access Token:', accessToken.substring(0, 20) + '...');
    return true;
  } catch (error) {
    if (error.response?.status === 400 && error.response?.data?.message?.includes('already exists')) {
      console.log('⚠️  User already exists, testing login instead...');
      return await testUserLogin();
    }
    console.error('❌ User registration failed:', error.response?.data || error.message);
    return false;
  }
}

async function testUserLogin() {
  try {
    console.log('\n🔐 Testing user login...');
    const response = await axios.post(`${BASE_URL}/auth/signin`, {
      email: testUser.email,
      password: testUser.password
    });
    console.log('✅ User login successful');
    
    accessToken = response.data.accessToken;
    refreshToken = response.data.refreshToken;
    
    console.log('Access Token:', accessToken.substring(0, 20) + '...');
    return true;
  } catch (error) {
    console.error('❌ User login failed:', error.response?.data || error.message);
    return false;
  }
}

async function testGetProfile() {
  try {
    console.log('\n👤 Testing get profile...');
    const response = await axios.get(`${BASE_URL}/profile`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    console.log('✅ Get profile successful');
    console.log('User:', response.data.user.firstName, response.data.user.lastName);
    return true;
  } catch (error) {
    console.error('❌ Get profile failed:', error.response?.data || error.message);
    return false;
  }
}

async function testUpdateProfile() {
  try {
    console.log('\n✏️  Testing update profile...');
    const updateData = {
      firstName: 'Updated',
      lastName: 'Name',
      phoneNumber: '+1234567890'
    };
    
    const response = await axios.put(`${BASE_URL}/profile`, updateData, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    console.log('✅ Update profile successful');
    console.log('Updated name:', response.data.user.firstName, response.data.user.lastName);
    return true;
  } catch (error) {
    console.error('❌ Update profile failed:', error.response?.data || error.message);
    return false;
  }
}

async function testGetContent() {
  try {
    console.log('\n📚 Testing get content...');
    const response = await axios.get(`${BASE_URL}/content`);
    console.log('✅ Get content successful');
    console.log('Content count:', response.data.total);
    return true;
  } catch (error) {
    console.error('❌ Get content failed:', error.response?.data || error.message);
    return false;
  }
}

async function testGetCategories() {
  try {
    console.log('\n🏷️  Testing get categories...');
    const response = await axios.get(`${BASE_URL}/content/categories`);
    console.log('✅ Get categories successful');
    console.log('Categories:', response.data.categories.map(c => c.name).join(', '));
    return true;
  } catch (error) {
    console.error('❌ Get categories failed:', error.response?.data || error.message);
    return false;
  }
}

async function testLogout() {
  try {
    console.log('\n🚪 Testing logout...');
    await axios.post(`${BASE_URL}/auth/logout`, {
      refreshToken: refreshToken
    }, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    console.log('✅ Logout successful');
    return true;
  } catch (error) {
    console.error('❌ Logout failed:', error.response?.data || error.message);
    return false;
  }
}

async function runAllTests() {
  console.log('🧪 MeditAi API Test Suite');
  console.log('========================\n');

  const tests = [
    { name: 'Health Check', fn: testHealthCheck },
    { name: 'User Registration/Login', fn: testUserRegistration },
    { name: 'Get Profile', fn: testGetProfile },
    { name: 'Update Profile', fn: testUpdateProfile },
    { name: 'Get Content', fn: testGetContent },
    { name: 'Get Categories', fn: testGetCategories },
    { name: 'Logout', fn: testLogout }
  ];

  let passed = 0;
  let failed = 0;

  for (const test of tests) {
    try {
      const result = await test.fn();
      if (result) {
        passed++;
      } else {
        failed++;
      }
    } catch (error) {
      console.error(`❌ ${test.name} failed with error:`, error.message);
      failed++;
    }
  }

  console.log('\n📊 Test Results');
  console.log('===============');
  console.log(`✅ Passed: ${passed}`);
  console.log(`❌ Failed: ${failed}`);
  console.log(`📈 Success Rate: ${Math.round((passed / (passed + failed)) * 100)}%`);

  if (failed === 0) {
    console.log('\n🎉 All tests passed! The API is working correctly.');
  } else {
    console.log('\n⚠️  Some tests failed. Please check the server logs and configuration.');
  }
}

// Run tests
runAllTests().catch(console.error); 