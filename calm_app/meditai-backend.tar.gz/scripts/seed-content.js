const { sequelize } = require('../config/database');
const Content = require('../models/Content');

const sampleContent = [
  // Meditation Content
  {
    title: 'Calming Anxiety',
    subtitle: 'Meditation • 3 minutes',
    description: 'A gentle meditation to help calm anxiety and find inner peace.',
    imageUrl: 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=400&q=80',
    category: 'meditation',
    tags: ['anxiety', 'calm', 'peace', 'mindfulness'],
    duration: 180,
    author: 'MeditAi',
    rating: 4.8,
    playCount: 1250,
    isPremium: false
  },
  {
    title: 'Mindful Morning',
    subtitle: 'Meditation • 10 minutes',
    description: 'Start your day with mindfulness and intention.',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400&q=80',
    category: 'meditation',
    tags: ['morning', 'mindfulness', 'intention', 'daily'],
    duration: 600,
    author: 'Mindful Living',
    rating: 4.9,
    playCount: 2800,
    isPremium: false
  },
  {
    title: 'Stress Relief',
    subtitle: 'Meditation • 5 minutes',
    description: 'Quick meditation to relieve stress and tension.',
    imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=400&q=80',
    category: 'meditation',
    tags: ['stress', 'relief', 'quick', 'calm'],
    duration: 300,
    author: 'Stress Relief Coach',
    rating: 4.6,
    playCount: 950,
    isPremium: false
  },

  // Sleep Content
  {
    title: 'Deep Sleep',
    subtitle: 'Sleep Music • 45 minutes',
    description: 'Soothing sounds to help you fall asleep naturally.',
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80',
    category: 'sleep',
    tags: ['sleep', 'relaxation', 'night', 'peaceful'],
    duration: 2700,
    author: 'Sleep Master',
    rating: 4.9,
    playCount: 3200,
    isPremium: true
  },
  {
    title: 'Insomnia Relief',
    subtitle: 'Sleep Stories • 30 minutes',
    description: 'Gentle stories to help you fall asleep naturally.',
    imageUrl: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=400&q=80',
    category: 'sleep',
    tags: ['insomnia', 'sleep', 'stories', 'relaxation'],
    duration: 1800,
    author: 'Sleep Master',
    rating: 4.7,
    playCount: 2100,
    isPremium: false
  },
  {
    title: 'Bedtime Stories',
    subtitle: 'Sleep Stories • 20 minutes',
    description: 'Peaceful bedtime stories for deep sleep.',
    imageUrl: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80',
    category: 'sleep',
    tags: ['bedtime', 'stories', 'sleep', 'peaceful'],
    duration: 1200,
    author: 'Story Master',
    rating: 4.5,
    playCount: 1800,
    isPremium: false
  },

  // Breathing Content
  {
    title: 'Breathing for Focus',
    subtitle: 'Breathing Exercise • 5 minutes',
    description: 'A focused breathing exercise to improve concentration.',
    imageUrl: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=400&q=80',
    category: 'breathing',
    tags: ['focus', 'breathing', 'concentration', 'energy'],
    duration: 300,
    author: 'Breath Coach',
    rating: 4.7,
    playCount: 890,
    isPremium: false
  },
  {
    title: 'Stress Relief Breathing',
    subtitle: 'Breathing Exercise • 7 minutes',
    description: 'Quick breathing exercise to relieve stress and tension.',
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80',
    category: 'breathing',
    tags: ['stress', 'relief', 'breathing', 'quick'],
    duration: 420,
    author: 'Stress Relief Coach',
    rating: 4.6,
    playCount: 950,
    isPremium: false
  },
  {
    title: 'Focus and Concentration',
    subtitle: 'Breathing Exercise • 5 minutes',
    description: 'Enhance your focus and concentration with this breathing technique.',
    imageUrl: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=400&q=80',
    category: 'breathing',
    tags: ['focus', 'concentration', 'breathing', 'productivity'],
    duration: 300,
    author: 'Focus Coach',
    rating: 4.5,
    playCount: 1800,
    isPremium: false
  },

  // Relaxation Content
  {
    title: 'Progressive Muscle Relaxation',
    subtitle: 'Relaxation • 15 minutes',
    description: 'Guided progressive muscle relaxation for complete body relaxation.',
    imageUrl: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80',
    category: 'relaxation',
    tags: ['muscle', 'relaxation', 'body', 'stress-relief'],
    duration: 900,
    author: 'Relaxation Expert',
    rating: 4.8,
    playCount: 1560,
    isPremium: true
  },
  {
    title: 'Evening Relaxation',
    subtitle: 'Music • 45 minutes',
    description: 'Soothing music to help you unwind and prepare for sleep.',
    imageUrl: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80',
    category: 'relaxation',
    tags: ['evening', 'relaxation', 'music', 'sleep'],
    duration: 2700,
    author: 'Relaxation Expert',
    rating: 4.8,
    playCount: 2800,
    isPremium: true
  },
  {
    title: 'Body Scan Meditation',
    subtitle: 'Relaxation • 20 minutes',
    description: 'Guided body scan meditation for deep relaxation.',
    imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=400&q=80',
    category: 'relaxation',
    tags: ['body-scan', 'meditation', 'relaxation', 'mindfulness'],
    duration: 1200,
    author: 'Mindfulness Coach',
    rating: 4.7,
    playCount: 1200,
    isPremium: false
  },

  // Music Content
  {
    title: 'Calm Piano',
    subtitle: 'Music • 30 minutes',
    description: 'Peaceful piano music for relaxation and focus.',
    imageUrl: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&w=400&q=80',
    category: 'music',
    tags: ['piano', 'calm', 'relaxation', 'focus'],
    duration: 1800,
    author: 'Piano Master',
    rating: 4.6,
    playCount: 2200,
    isPremium: false
  },
  {
    title: 'Ambient Sounds',
    subtitle: 'Music • 60 minutes',
    description: 'Ambient music for deep relaxation and meditation.',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400&q=80',
    category: 'music',
    tags: ['ambient', 'relaxation', 'meditation', 'peaceful'],
    duration: 3600,
    author: 'Ambient Artist',
    rating: 4.5,
    playCount: 1500,
    isPremium: true
  },
  {
    title: 'Nature Melodies',
    subtitle: 'Music • 45 minutes',
    description: 'Melodic nature-inspired music for tranquility.',
    imageUrl: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=400&q=80',
    category: 'music',
    tags: ['nature', 'melodies', 'tranquility', 'peaceful'],
    duration: 2700,
    author: 'Nature Composer',
    rating: 4.4,
    playCount: 1100,
    isPremium: false
  },

  // Nature Content
  {
    title: 'Ocean Waves',
    subtitle: 'Nature Sounds • 30 minutes',
    description: 'Relaxing ocean wave sounds for deep relaxation.',
    imageUrl: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=400&q=80',
    category: 'nature',
    tags: ['ocean', 'waves', 'nature', 'relaxation'],
    duration: 1800,
    author: 'Nature Sounds',
    rating: 4.6,
    playCount: 2100,
    isPremium: false
  },
  {
    title: 'Forest Ambience',
    subtitle: 'Nature Sounds • 60 minutes',
    description: 'Immerse yourself in the peaceful sounds of the forest.',
    imageUrl: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=400&q=80',
    category: 'nature',
    tags: ['forest', 'nature', 'peaceful', 'ambience'],
    duration: 3600,
    author: 'Nature Sounds',
    rating: 4.7,
    playCount: 1800,
    isPremium: true
  },
  {
    title: 'Rain Sounds',
    subtitle: 'Nature Sounds • 45 minutes',
    description: 'Soothing rain sounds for relaxation and sleep.',
    imageUrl: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=400&q=80',
    category: 'nature',
    tags: ['rain', 'nature', 'relaxation', 'sleep'],
    duration: 2700,
    author: 'Nature Sounds',
    rating: 4.5,
    playCount: 1600,
    isPremium: false
  }
];

async function seedContent() {
  try {
    console.log('🌱 Seeding content data...');
    
    // Clear existing content
    await Content.destroy({ where: {} });
    console.log('✅ Cleared existing content');
    
    // Create new content
    for (const contentData of sampleContent) {
      await Content.create(contentData);
    }
    
    console.log(`✅ Successfully seeded ${sampleContent.length} content items`);
    
    // Display statistics
    const totalContent = await Content.count();
    const categoryStats = await Content.findAll({
      attributes: [
        'category',
        [Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'count']
      ],
      group: ['category'],
      order: [[Content.sequelize.fn('COUNT', Content.sequelize.col('id')), 'DESC']]
    });
    
    console.log('\n📊 Content Statistics:');
    console.log(`Total content: ${totalContent}`);
    categoryStats.forEach(stat => {
      console.log(`${stat.category}: ${stat.getDataValue('count')} items`);
    });
    
  } catch (error) {
    console.error('❌ Error seeding content:', error);
    throw error;
  }
}

// Run seeding if this file is executed directly
if (require.main === module) {
  seedContent()
    .then(() => {
      console.log('🎉 Content seeding completed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Content seeding failed:', error);
      process.exit(1);
    });
}

module.exports = { seedContent }; 