const { verifyAccessToken } = require('../utils/jwt');
const User = require('../models/User');
const RefreshToken = require('../models/RefreshToken');

// Middleware to authenticate user with JWT token
const authenticateToken = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({
        error: 'Access denied',
        message: 'No token provided'
      });
    }

    // Verify token
    const decoded = verifyAccessToken(token);
    
    // Check if user exists and is active
    const user = await User.findByPk(decoded.userId);
    if (!user || !user.isActive) {
      return res.status(401).json({
        error: 'Access denied',
        message: 'User not found or inactive'
      });
    }

    // Add user to request object
    req.user = user;
    req.userId = decoded.userId;
    next();
  } catch (error) {
    return res.status(401).json({
      error: 'Access denied',
      message: error.message
    });
  }
};

// Middleware to check if user is verified
const requireEmailVerification = async (req, res, next) => {
  try {
    if (!req.user.isEmailVerified) {
      return res.status(403).json({
        error: 'Email verification required',
        message: 'Please verify your email address before accessing this resource'
      });
    }
    next();
  } catch (error) {
    return res.status(500).json({
      error: 'Server error',
      message: error.message
    });
  }
};

// Middleware to check if user has accepted terms
const requireTermsAcceptance = async (req, res, next) => {
  try {
    if (!req.user.acceptPrivacyPolicy || !req.user.acceptTermsOfService) {
      return res.status(403).json({
        error: 'Terms acceptance required',
        message: 'Please accept privacy policy and terms of service'
      });
    }
    next();
  } catch (error) {
    return res.status(500).json({
      error: 'Server error',
      message: error.message
    });
  }
};

// Middleware to check if user has premium subscription
const requirePremium = async (req, res, next) => {
  try {
    const user = req.user;
    const now = new Date();
    
    // Check if user has active premium subscription
    const hasActiveSubscription = 
      user.subscriptionStatus === 'premium' && 
      user.subscriptionExpiresAt && 
      user.subscriptionExpiresAt > now;
    
    // Check if user is in trial period
    const isInTrial = 
      user.subscriptionStatus === 'trial' && 
      user.subscriptionExpiresAt && 
      user.subscriptionExpiresAt > now;

    if (!hasActiveSubscription && !isInTrial) {
      return res.status(403).json({
        error: 'Premium subscription required',
        message: 'This feature requires a premium subscription'
      });
    }
    next();
  } catch (error) {
    return res.status(500).json({
      error: 'Server error',
      message: error.message
    });
  }
};

// Middleware to check if user is not locked
const checkAccountLock = async (req, res, next) => {
  try {
    const user = req.user;
    
    if (user.lockUntil && user.lockUntil > new Date()) {
      return res.status(423).json({
        error: 'Account locked',
        message: 'Your account has been temporarily locked due to multiple failed login attempts'
      });
    }
    next();
  } catch (error) {
    return res.status(500).json({
      error: 'Server error',
      message: error.message
    });
  }
};

// Middleware to get user from token (optional authentication)
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];

    if (token) {
      try {
        const decoded = verifyAccessToken(token);
        const user = await User.findByPk(decoded.userId);
        if (user && user.isActive) {
          req.user = user;
          req.userId = decoded.userId;
        }
      } catch (error) {
        // Token is invalid, but we don't block the request
        console.log('Invalid token in optional auth:', error.message);
      }
    }
    next();
  } catch (error) {
    next();
  }
};

// Middleware to check user permissions
const checkPermission = (permission) => {
  return async (req, res, next) => {
    try {
      const user = req.user;
      
      // Check if user has the required permission
      const userPermissions = user.preferences?.permissions || [];
      
      if (!userPermissions.includes(permission)) {
        return res.status(403).json({
          error: 'Permission denied',
          message: `You don't have permission to ${permission}`
        });
      }
      next();
    } catch (error) {
      return res.status(500).json({
        error: 'Server error',
        message: error.message
      });
    }
  };
};

// Middleware to rate limit login attempts
const rateLimitLogin = (req, res, next) => {
  // This would typically use a rate limiting library like express-rate-limit
  // For now, we'll implement basic rate limiting
  const user = req.user;
  
  if (user && user.loginAttempts >= 5) {
    const lockTime = new Date();
    lockTime.setMinutes(lockTime.getMinutes() + 15); // Lock for 15 minutes
    
    if (!user.lockUntil || user.lockUntil < new Date()) {
      // Reset lock if it has expired
      user.update({
        loginAttempts: 0,
        lockUntil: null
      });
    } else {
      return res.status(423).json({
        error: 'Account temporarily locked',
        message: 'Too many failed login attempts. Please try again later.'
      });
    }
  }
  next();
};

module.exports = {
  authenticateToken,
  requireEmailVerification,
  requireTermsAcceptance,
  requirePremium,
  checkAccountLock,
  optionalAuth,
  checkPermission,
  rateLimitLogin
}; 