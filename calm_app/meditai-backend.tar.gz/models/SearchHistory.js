const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const SearchHistory = sequelize.define('SearchHistory', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    },
    field: 'user_id'
  },
  query: {
    type: DataTypes.STRING,
    allowNull: false
  },
  resultCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    field: 'result_count'
  },
  filters: {
    type: DataTypes.JSONB,
    defaultValue: {}
  },
  userAgent: {
    type: DataTypes.STRING,
    field: 'user_agent'
  },
  ipAddress: {
    type: DataTypes.STRING,
    field: 'ip_address'
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'created_at'
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'updated_at'
  }
}, {
  tableName: 'search_history',
  timestamps: true,
  underscored: true,
  indexes: [
    {
      fields: ['user_id']
    },
    {
      fields: ['query']
    },
    {
      fields: ['created_at']
    }
  ]
});

// Instance methods
SearchHistory.prototype.toJSON = function() {
  const values = Object.assign({}, this.get());
  return values;
};

// Class methods
SearchHistory.findByUser = function(userId, limit = 20) {
  return this.findAll({
    where: { userId },
    order: [['createdAt', 'DESC']],
    limit
  });
};

SearchHistory.getPopularQueries = function(limit = 10) {
  return this.findAll({
    attributes: [
      'query',
      [sequelize.fn('COUNT', sequelize.col('id')), 'count']
    ],
    group: ['query'],
    order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
    limit
  });
};

SearchHistory.getRecentQueries = function(limit = 10) {
  return this.findAll({
    attributes: ['query'],
    order: [['createdAt', 'DESC']],
    limit,
    group: ['query']
  });
};

SearchHistory.clearUserHistory = function(userId) {
  return this.destroy({
    where: { userId }
  });
};

module.exports = SearchHistory; 