const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const SearchAnalytics = sequelize.define('SearchAnalytics', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  query: {
    type: DataTypes.STRING,
    allowNull: false
  },
  resultCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    field: 'result_count'
  },
  clickCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    field: 'click_count'
  },
  avgClickPosition: {
    type: DataTypes.FLOAT,
    defaultValue: 0,
    field: 'avg_click_position'
  },
  searchCount: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
    field: 'search_count'
  },
  filters: {
    type: DataTypes.JSONB,
    defaultValue: {}
  },
  category: {
    type: DataTypes.STRING
  },
  createdAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'created_at'
  },
  updatedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
    field: 'updated_at'
  }
}, {
  tableName: 'search_analytics',
  timestamps: true,
  underscored: true,
  indexes: [
    {
      fields: ['query']
    },
    {
      fields: ['category']
    },
    {
      fields: ['created_at']
    }
  ]
});

// Instance methods
SearchAnalytics.prototype.toJSON = function() {
  const values = Object.assign({}, this.get());
  return values;
};

// Class methods
SearchAnalytics.getPopularQueries = function(limit = 10) {
  return this.findAll({
    attributes: [
      'query',
      'searchCount',
      'clickCount',
      [sequelize.fn('ROUND', sequelize.literal('click_count::float / search_count'), 2), 'clickRate']
    ],
    order: [['searchCount', 'DESC']],
    limit
  });
};

SearchAnalytics.getTrendingQueries = function(days = 7, limit = 10) {
  const dateThreshold = new Date();
  dateThreshold.setDate(dateThreshold.getDate() - days);

  return this.findAll({
    where: {
      createdAt: {
        [sequelize.Op.gte]: dateThreshold
      }
    },
    attributes: [
      'query',
      [sequelize.fn('COUNT', sequelize.col('id')), 'recentSearches']
    ],
    group: ['query'],
    order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
    limit
  });
};

SearchAnalytics.getCategoryStats = function() {
  return this.findAll({
    attributes: [
      'category',
      [sequelize.fn('COUNT', sequelize.col('id')), 'searchCount'],
      [sequelize.fn('AVG', sequelize.col('result_count')), 'avgResults'],
      [sequelize.fn('AVG', sequelize.col('click_count')), 'avgClicks']
    ],
    group: ['category'],
    order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']]
  });
};

SearchAnalytics.recordSearch = function(query, resultCount, filters = {}, category = null) {
  return this.findOrCreate({
    where: { query },
    defaults: {
      resultCount,
      filters,
      category
    }
  }).then(([analytics, created]) => {
    if (!created) {
      return analytics.increment({
        searchCount: 1,
        resultCount: resultCount
      });
    }
    return analytics;
  });
};

SearchAnalytics.recordClick = function(query, position) {
  return this.findOne({
    where: { query }
  }).then(analytics => {
    if (analytics) {
      const newClickCount = analytics.clickCount + 1;
      const newAvgPosition = ((analytics.avgClickPosition * analytics.clickCount) + position) / newClickCount;
      
      return analytics.update({
        clickCount: newClickCount,
        avgClickPosition: newAvgPosition
      });
    }
  });
};

module.exports = SearchAnalytics; 