const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const bcrypt = require('bcryptjs');

const User = sequelize.define('User', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING(255),
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true,
      notEmpty: true
    }
  },
  password: {
    type: DataTypes.STRING(255),
    allowNull: false,
    validate: {
      notEmpty: true,
      len: [6, 255]
    }
  },
  firstName: {
    type: DataTypes.STRING(255),
    allowNull: false,
    field: 'first_name',
    validate: {
      notEmpty: true,
      len: [1, 255]
    }
  },
  lastName: {
    type: DataTypes.STRING(255),
    allowNull: false,
    field: 'last_name',
    validate: {
      notEmpty: true,
      len: [1, 255]
    }
  },
  isEmailVerified: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'is_email_verified'
  },
  emailVerificationToken: {
    type: DataTypes.STRING(255),
    field: 'email_verification_token'
  },
  emailVerificationExpires: {
    type: DataTypes.DATE,
    field: 'email_verification_expires'
  },
  passwordResetToken: {
    type: DataTypes.STRING(255),
    field: 'password_reset_token'
  },
  passwordResetExpires: {
    type: DataTypes.DATE,
    field: 'password_reset_expires'
  },
  authProvider: {
    type: DataTypes.ENUM('email', 'google', 'facebook', 'apple'),
    defaultValue: 'email',
    field: 'auth_provider'
  },
  providerId: {
    type: DataTypes.STRING(255),
    field: 'provider_id'
  },
  avatar: {
    type: DataTypes.STRING(255),
    defaultValue: 'https://via.placeholder.com/150',
    validate: {
      isUrl: true
    }
  },
  dateOfBirth: {
    type: DataTypes.DATEONLY,
    field: 'date_of_birth',
    validate: {
      isDate: true
    }
  },
  gender: {
    type: DataTypes.ENUM('male', 'female', 'other', 'prefer_not_to_say'),
    field: 'gender'
  },
  phoneNumber: {
    type: DataTypes.STRING(255),
    field: 'phone_number'
  },
  timezone: {
    type: DataTypes.STRING(255),
    defaultValue: 'UTC',
    field: 'timezone'
  },
  language: {
    type: DataTypes.STRING(255),
    defaultValue: 'en',
    field: 'language'
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
    field: 'is_active'
  },
  lastLoginAt: {
    type: DataTypes.DATE,
    field: 'last_login_at'
  },
  loginAttempts: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    field: 'login_attempts'
  },
  lockUntil: {
    type: DataTypes.DATE,
    field: 'lock_until'
  },
  acceptPrivacyPolicy: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'accept_privacy_policy'
  },
  acceptTermsOfService: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'accept_terms_of_service'
  },
  privacyPolicyAcceptedAt: {
    type: DataTypes.DATE,
    field: 'privacy_policy_accepted_at'
  },
  termsOfServiceAcceptedAt: {
    type: DataTypes.DATE,
    field: 'terms_of_service_accepted_at'
  },
  preferences: {
    type: DataTypes.JSONB,
    defaultValue: {}
  },
  goals: {
    type: DataTypes.ARRAY(DataTypes.STRING(255)),
    defaultValue: []
  },
  referralSource: {
    type: DataTypes.STRING(255),
    field: 'referral_source'
  },
  subscriptionStatus: {
    type: DataTypes.ENUM('free', 'premium', 'trial', 'expired'),
    defaultValue: 'free',
    field: 'subscription_status'
  },
  subscriptionExpiresAt: {
    type: DataTypes.DATE,
    field: 'subscription_expires_at'
  }
}, {
  tableName: 'users',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at',
  hooks: {
    beforeCreate: async (user) => {
      if (user.password) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
      }
    },
    beforeUpdate: async (user) => {
      if (user.changed('password')) {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
      }
    }
  }
});

// Instance methods
User.prototype.isLocked = function() {
  return this.lockUntil && this.lockUntil > new Date();
};

User.prototype.incrementLoginAttempts = async function() {
  this.loginAttempts += 1;
  if (this.loginAttempts >= 5) {
    this.lockUntil = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
  }
  await this.save();
};

User.prototype.resetLoginAttempts = async function() {
  this.loginAttempts = 0;
  this.lockUntil = null;
  this.lastLoginAt = new Date();
  await this.save();
};

// Password comparison method
User.prototype.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Class methods
User.findByEmail = function(email) {
  return this.findOne({ where: { email: email.toLowerCase() } });
};

User.findByProvider = function(provider, providerId) {
  return this.findOne({ 
    where: { 
      authProvider: provider,
      providerId: providerId 
    } 
  });
};

module.exports = User; 