const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Content = sequelize.define('Content', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
    allowNull: false
  },
  title: {
    type: DataTypes.STRING(255),
    allowNull: false,
    validate: {
      notEmpty: true,
      len: [1, 255]
    }
  },
  subtitle: {
    type: DataTypes.STRING(255),
    allowNull: true,
    validate: {
      len: [0, 255]
    }
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  imageUrl: {
    type: DataTypes.STRING(500),
    allowNull: true,
    field: 'image_url',
    validate: {
      isUrl: true
    }
  },
  audioUrl: {
    type: DataTypes.STRING(500),
    allowNull: true,
    field: 'audio_url',
    validate: {
      isUrl: true
    }
  },
  category: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      notEmpty: true,
      len: [1, 100]
    }
  },
  tags: {
    type: DataTypes.ARRAY(DataTypes.STRING(255)),
    defaultValue: []
  },
  duration: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1
    }
  },
  author: {
    type: DataTypes.STRING(255),
    allowNull: true,
    validate: {
      len: [0, 255]
    }
  },
  rating: {
    type: DataTypes.DECIMAL(3, 2),
    defaultValue: 0.0,
    validate: {
      min: 0.0,
      max: 5.0
    }
  },
  playCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    field: 'play_count',
    validate: {
      min: 0
    }
  },
  isPremium: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
    field: 'is_premium'
  }
}, {
  tableName: 'content',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

// Class methods
Content.findByCategory = function(category) {
  return this.findAll({ 
    where: { category: category.toLowerCase() },
    order: [['createdAt', 'DESC']]
  });
};

Content.search = function(query) {
  const { Op } = require('sequelize');
  return this.findAll({
    where: {
      [Op.or]: [
        { title: { [Op.iLike]: `%${query}%` } },
        { description: { [Op.iLike]: `%${query}%` } },
        { tags: { [Op.overlap]: [query] } }
      ]
    },
    order: [['playCount', 'DESC']]
  });
};

Content.getPopular = function(limit = 10) {
  return this.findAll({
    order: [['playCount', 'DESC']],
    limit: limit
  });
};

module.exports = Content; 