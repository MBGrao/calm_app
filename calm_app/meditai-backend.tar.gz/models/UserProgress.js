const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const User = require('./User');
const Content = require('./Content');

const UserProgress = sequelize.define('UserProgress', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
    allowNull: false
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    field: 'user_id',
    references: {
      model: User,
      key: 'id'
    }
  },
  sessionType: {
    type: DataTypes.STRING(50),
    allowNull: false,
    field: 'session_type',
    defaultValue: 'meditation'
  },
  duration: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 0
    }
  },
  startedAt: {
    type: DataTypes.DATE,
    allowNull: false,
    field: 'started_at',
    defaultValue: DataTypes.NOW
  },
  completedAt: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'completed_at'
  },
  metadata: {
    type: DataTypes.JSONB,
    defaultValue: {}
  }
}, {
  tableName: 'user_sessions',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false // user_sessions table doesn't have updated_at
});

// Associations
UserProgress.belongsTo(User, { foreignKey: 'userId' });
UserProgress.belongsTo(Content, { foreignKey: 'contentId', as: 'content' });

// Class methods
UserProgress.getUserStats = async function(userId) {
  const stats = await sequelize.query(`
    SELECT 
      COUNT(*) as total_sessions,
      SUM(duration) as total_minutes,
      COUNT(DISTINCT DATE(started_at)) as unique_days,
      MAX(started_at) as last_session
    FROM user_sessions 
    WHERE user_id = :userId
  `, {
    replacements: { userId },
    type: sequelize.QueryTypes.SELECT
  });
  
  return stats[0];
};

UserProgress.getUserStreak = async function(userId) {
  const streak = await sequelize.query(`
    WITH daily_sessions AS (
      SELECT DISTINCT DATE(started_at) as session_date
      FROM user_sessions 
      WHERE user_id = :userId
      ORDER BY session_date DESC
    ),
    streak_calc AS (
      SELECT 
        session_date,
        ROW_NUMBER() OVER (ORDER BY session_date DESC) as rn,
        session_date - ROW_NUMBER() OVER (ORDER BY session_date DESC) * INTERVAL '1 day' as grp
      FROM daily_sessions
    )
    SELECT COUNT(*) as current_streak
    FROM streak_calc
    WHERE grp = (SELECT grp FROM streak_calc WHERE rn = 1)
  `, {
    replacements: { userId },
    type: sequelize.QueryTypes.SELECT
  });
  
  return streak[0]?.current_streak || 0;
};

// Instance method to record session
UserProgress.recordSession = async function(userId, contentId, duration, metadata = {}) {
  return await this.create({
    userId,
    contentId,
    sessionType: 'meditation',
    duration,
    startedAt: new Date(),
    completedAt: new Date(),
    metadata
  });
};

module.exports = UserProgress; 