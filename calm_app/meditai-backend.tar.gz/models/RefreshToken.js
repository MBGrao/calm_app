const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const User = require('./User');

const RefreshToken = sequelize.define('RefreshToken', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true,
    allowNull: false
  },
  token: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  userId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  expiresAt: {
    type: DataTypes.DATE,
    allowNull: false
  },
  isRevoked: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  ipAddress: {
    type: DataTypes.STRING,
    allowNull: true
  },
  userAgent: {
    type: DataTypes.STRING,
    allowNull: true
  }
}, {
  tableName: 'refresh_tokens',
  timestamps: true
});

// Associations
RefreshToken.belongsTo(User, { foreignKey: 'userId', as: 'user' });
User.hasMany(RefreshToken, { foreignKey: 'userId', as: 'refreshTokens' });

// Instance methods
RefreshToken.prototype.isExpired = function() {
  return new Date() > this.expiresAt;
};

RefreshToken.prototype.isValid = function() {
  return !this.isRevoked && !this.isExpired();
};

// Class methods
RefreshToken.createToken = async function(userId, expiresIn = '30d') {
  try {
    const crypto = require('crypto');
    const token = crypto.randomBytes(40).toString('hex');
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30); // 30 days from now

    const refreshToken = await this.create({
      token,
      userId,
      expiresAt
    });

    return refreshToken;
  } catch (error) {
    console.error('Error creating refresh token:', error);
    throw new Error('Failed to create refresh token');
  }
};

RefreshToken.findByToken = function(token) {
  return this.findOne({ 
    where: { token },
    include: [{ model: User, as: 'user' }]
  });
};

RefreshToken.revokeToken = function(token) {
  return this.update(
    { isRevoked: true },
    { where: { token } }
  );
};

RefreshToken.revokeAllUserTokens = function(userId) {
  return this.update(
    { isRevoked: true },
    { where: { userId } }
  );
};

RefreshToken.cleanupExpiredTokens = async function() {
  const { Op } = require('sequelize');
  return this.destroy({
    where: {
      expiresAt: {
        [Op.lt]: new Date()
      }
    }
  });
};

module.exports = RefreshToken; 