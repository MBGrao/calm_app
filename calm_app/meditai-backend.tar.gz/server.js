const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const { sequelize } = require('./config/database');
const authRoutes = require('./routes/auth');
const profileRoutes = require('./routes/profile');
const contentRoutes = require('./routes/content');
const progressRoutes = require('./routes/progress');
const searchRoutes = require('./routes/search');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet());

// CORS configuration
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:8080',
    'http://localhost:3000',
    'http://127.0.0.1:3000',
    'http://10.0.2.2:3000', // Android emulator
    'http://localhost:8080', // Flutter web
    'http://localhost:8081', // Flutter web alternative
    'http://localhost:8082', // Flutter web alternative
    'http://localhost:8083', // Flutter web alternative
    'http://localhost:8084', // Flutter web alternative
    'http://localhost:8085', // Flutter web alternative
    'http://localhost:8086', // Flutter web alternative
    'http://localhost:8087', // Flutter web alternative
    'http://localhost:8088', // Flutter web alternative
    'http://localhost:8089', // Flutter web alternative
    'http://localhost:8090', // Flutter web alternative
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept'],
  exposedHeaders: ['Content-Range', 'X-Content-Range']
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // limit each IP to 100 requests per windowMs
  message: {
    error: 'Too many requests from this IP, please try again later.'
  }
});
app.use('/api/', limiter);

// Logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    message: 'MeditAi API is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    version: '1.0.0'
  });
});

// API documentation endpoint
app.get('/api/v1', (req, res) => {
  res.json({
    name: 'MeditAi API',
    version: '1.0.0',
    description: 'Backend API for MeditAi meditation app',
    endpoints: {
      auth: {
        'POST /signup': 'Register a new user',
        'POST /signin': 'Authenticate user',
        'POST /refresh': 'Refresh access token',
        'POST /logout': 'Logout user',
        'POST /forgot-password': 'Request password reset',
        'POST /reset-password': 'Reset password',
        'POST /verify-email': 'Verify email address',
        'GET /me': 'Get current user info'
      },
      profile: {
        'GET /': 'Get user profile',
        'PUT /': 'Update user profile',
        'DELETE /': 'Delete user account',
        'PUT /change-password': 'Change password',
        'POST /privacy-policy': 'Accept privacy policy',
        'POST /terms-of-service': 'Accept terms of service',
        'PUT /goals': 'Update user goals',
        'PUT /preferences': 'Update user preferences',
        'GET /stats': 'Get user statistics'
      },
      content: {
        'GET /': 'Get all content',
        'GET /:id': 'Get content by ID',
        'GET /category/:category': 'Get content by category',
        'GET /search': 'Search content',
        'GET /recommended': 'Get recommended content',
        'GET /categories': 'Get all categories'
      },
      progress: {
        'POST /': 'Record meditation session',
        'GET /': 'Get recent sessions',
        'GET /stats': 'Get user statistics',
        'GET /streak': 'Get user streak',
        'GET /weekly': 'Get weekly statistics',
        'GET /monthly': 'Get monthly statistics',
        'GET /favorites': 'Get favorite categories',
        'GET /:id': 'Get session by ID',
        'DELETE /:id': 'Delete session'
      },
      search: {
        'GET /': 'Search content',
        'GET /:query': 'Search content by query'
      }
    },
    baseUrl: `http://localhost:${PORT}/api/v1`
  });
});

// API routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/profile', profileRoutes);
app.use('/api/v1/content', contentRoutes);
app.use('/api/v1/progress', progressRoutes);
app.use('/api/v1/search', searchRoutes);

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Route not found',
    message: `Cannot ${req.method} ${req.originalUrl}`
  });
});

// Error handling middleware
app.use(errorHandler);

// Database connection and server startup
async function startServer() {
  try {
    // Test database connection
    await sequelize.authenticate();
    console.log('✅ Database connection established successfully.');

    // Sync database models (in development)
    if (process.env.NODE_ENV === 'development') {
      await sequelize.sync({ alter: true });
      console.log('✅ Database models synchronized.');
    }

    // Start server
    app.listen(PORT, () => {
      console.log(`🚀 MeditAi API server running on port ${PORT}`);
      console.log(`📱 Environment: ${process.env.NODE_ENV}`);
      console.log(`🔗 Health check: http://localhost:${PORT}/health`);
      console.log(`📚 API Documentation: http://localhost:${PORT}/api/v1`);
    });

  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('🛑 SIGTERM received, shutting down gracefully...');
  await sequelize.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('🛑 SIGINT received, shutting down gracefully...');
  await sequelize.close();
  process.exit(0);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  process.exit(1);
});

startServer(); 