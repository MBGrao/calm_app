const axios = require('axios');

// Test the URL that Flutter app will use
const FLUTTER_URL = 'http://10.0.2.2:3000';

async function testFlutterConnection() {
  console.log('🧪 Testing Flutter App Connection');
  console.log('================================\n');

  try {
    // Test health endpoint
    console.log('🏥 Testing health endpoint...');
    const healthResponse = await axios.get(`${FLUTTER_URL}/health`);
    console.log('✅ Health check passed:', healthResponse.data);

    // Test API documentation
    console.log('\n📚 Testing API documentation...');
    const apiResponse = await axios.get(`${FLUTTER_URL}/api/v1`);
    console.log('✅ API documentation accessible');

    // Test auth endpoint
    console.log('\n🔐 Testing auth endpoint...');
    const authResponse = await axios.get(`${FLUTTER_URL}/api/v1/auth`);
    console.log('✅ Auth endpoint accessible');

    // Test signup endpoint
    console.log('\n📝 Testing signup endpoint...');
    const signupResponse = await axios.post(`${FLUTTER_URL}/api/v1/auth/signup`, {
      email: 'flutter-test@example.com',
      password: 'password123',
      firstName: 'Flutter',
      lastName: 'Test',
      acceptPrivacyPolicy: true,
      acceptTermsOfService: true
    });
    console.log('✅ Signup endpoint working');
    console.log('User ID:', signupResponse.data.user.id);

    console.log('\n🎉 All Flutter connection tests passed!');
    console.log('Your Flutter app should now be able to connect to the backend.');
    console.log(`Backend URL: ${FLUTTER_URL}/api/v1`);

  } catch (error) {
    console.error('❌ Flutter connection test failed:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data);
    }
  }
}

testFlutterConnection(); 