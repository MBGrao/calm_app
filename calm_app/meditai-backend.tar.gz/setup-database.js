const { sequelize } = require('./config/database');
const User = require('./models/User');
const Content = require('./models/Content');
const UserProgress = require('./models/UserProgress');
const SearchHistory = require('./models/SearchHistory');
const SearchAnalytics = require('./models/SearchAnalytics');

async function setupDatabase() {
  try {
    console.log('🔧 Setting up database...');

    // Test connection
    await sequelize.authenticate();
    console.log('✅ Database connection established.');

    // Sync all models
    await sequelize.sync({ force: true });
    console.log('✅ Database tables created.');

    // Create search-related tables
    console.log('📊 Creating search analytics tables...');
    
    // Create search_history table
    await sequelize.query(`
      CREATE TABLE IF NOT EXISTS search_history (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        query VARCHAR(255) NOT NULL,
        result_count INTEGER DEFAULT 0,
        filters JSONB DEFAULT '{}',
        user_agent VARCHAR(500),
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create search_analytics table
    await sequelize.query(`
      CREATE TABLE IF NOT EXISTS search_analytics (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        query VARCHAR(255) NOT NULL,
        result_count INTEGER DEFAULT 0,
        click_count INTEGER DEFAULT 0,
        avg_click_position FLOAT DEFAULT 0,
        search_count INTEGER DEFAULT 1,
        filters JSONB DEFAULT '{}',
        category VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create indexes for search tables
    await sequelize.query(`
      CREATE INDEX IF NOT EXISTS idx_search_history_user_id ON search_history(user_id);
      CREATE INDEX IF NOT EXISTS idx_search_history_query ON search_history(query);
      CREATE INDEX IF NOT EXISTS idx_search_history_created_at ON search_history(created_at);
      CREATE INDEX IF NOT EXISTS idx_search_analytics_query ON search_analytics(query);
      CREATE INDEX IF NOT EXISTS idx_search_analytics_category ON search_analytics(category);
      CREATE INDEX IF NOT EXISTS idx_search_analytics_created_at ON search_analytics(created_at);
    `);

    console.log('✅ Search tables and indexes created.');

    // Seed sample data
    console.log('🌱 Seeding sample data...');
    
    // Create sample users
    const users = await User.bulkCreate([
      {
        email: 'user1@example.com',
        password: '$2b$10$rQZ8K9vX8K9vX8K9vX8K9O',
        firstName: 'John',
        lastName: 'Doe',
        isPremium: false
      },
      {
        email: 'user2@example.com',
        password: '$2b$10$rQZ8K9vX8K9vX8K9vX8K9O',
        firstName: 'Jane',
        lastName: 'Smith',
        isPremium: true
      }
    ]);
    console.log(`✅ Created ${users.length} sample users.`);

    // Create sample content
    const content = await Content.bulkCreate([
      {
        title: 'Calming Anxiety',
        subtitle: 'Meditation • 3 minutes',
        description: 'A gentle meditation to help calm anxiety and find inner peace.',
        imageUrl: 'https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=400&q=80',
        category: 'meditation',
        tags: ['anxiety', 'calm', 'peace', 'mindfulness'],
        duration: 180,
        author: 'MeditAi',
        rating: 4.8,
        playCount: 1250,
        isPremium: false
      },
      {
        title: 'Deep Sleep',
        subtitle: 'Sleep Music • 45 minutes',
        description: 'Soothing sounds to help you fall asleep naturally.',
        imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80',
        category: 'sleep',
        tags: ['sleep', 'relaxation', 'night', 'peaceful'],
        duration: 2700,
        author: 'Sleep Master',
        rating: 4.9,
        playCount: 3200,
        isPremium: true
      },
      {
        title: 'Breathing for Focus',
        subtitle: 'Breathing Exercise • 5 minutes',
        description: 'A focused breathing exercise to improve concentration.',
        imageUrl: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=400&q=80',
        category: 'breathing',
        tags: ['focus', 'breathing', 'concentration', 'energy'],
        duration: 300,
        author: 'Breath Coach',
        rating: 4.7,
        playCount: 890,
        isPremium: false
      }
    ]);
    console.log(`✅ Created ${content.length} sample content items.`);

    // Create sample search history
    const searchHistory = await SearchHistory.bulkCreate([
      {
        userId: users[0].id,
        query: 'meditation',
        resultCount: 15,
        filters: { category: 'meditation' }
      },
      {
        userId: users[0].id,
        query: 'sleep',
        resultCount: 8,
        filters: { category: 'sleep' }
      },
      {
        userId: users[1].id,
        query: 'anxiety relief',
        resultCount: 12,
        filters: { tags: ['anxiety'] }
      }
    ]);
    console.log(`✅ Created ${searchHistory.length} sample search history entries.`);

    // Create sample search analytics
    const searchAnalytics = await SearchAnalytics.bulkCreate([
      {
        query: 'meditation',
        resultCount: 15,
        searchCount: 45,
        clickCount: 32,
        avgClickPosition: 2.1,
        category: 'meditation'
      },
      {
        query: 'sleep',
        resultCount: 8,
        searchCount: 28,
        clickCount: 22,
        avgClickPosition: 1.8,
        category: 'sleep'
      },
      {
        query: 'anxiety',
        resultCount: 12,
        searchCount: 33,
        clickCount: 25,
        avgClickPosition: 2.3,
        category: 'meditation'
      }
    ]);
    console.log(`✅ Created ${searchAnalytics.length} sample search analytics entries.`);

    console.log('🎉 Database setup completed successfully!');
    console.log('\n📊 Database Summary:');
    console.log(`   Users: ${users.length}`);
    console.log(`   Content: ${content.length}`);
    console.log(`   Search History: ${searchHistory.length}`);
    console.log(`   Search Analytics: ${searchAnalytics.length}`);

  } catch (error) {
    console.error('❌ Database setup failed:', error);
    throw error;
  } finally {
    await sequelize.close();
  }
}

// Run setup if this file is executed directly
if (require.main === module) {
  setupDatabase()
    .then(() => {
      console.log('✅ Setup completed successfully!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Setup failed:', error);
      process.exit(1);
    });
}

module.exports = { setupDatabase }; 