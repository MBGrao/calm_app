#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 MeditAi Backend Setup');
console.log('========================\n');

// Check if .env file exists
const envPath = path.join(__dirname, '.env');
if (!fs.existsSync(envPath)) {
  console.log('📝 Creating .env file...');
  
  const envContent = `# Server Configuration
PORT=3000
NODE_ENV=development

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=meditai_db
DB_USER=postgres
DB_PASSWORD=postgres

# JWT Configuration
JWT_SECRET=meditai_super_secret_jwt_key_2024_make_it_long_and_random_for_production
JWT_EXPIRES_IN=7d
JWT_REFRESH_EXPIRES_IN=30d

# Email Configuration (for password reset)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_email_app_password

# App Configuration
APP_NAME=MeditAi
APP_URL=http://localhost:3000
FRONTEND_URL=http://localhost:8080

# Security
BCRYPT_ROUNDS=12
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# File Upload
MAX_FILE_SIZE=5242880
UPLOAD_PATH=./uploads
`;

  fs.writeFileSync(envPath, envContent);
  console.log('✅ .env file created successfully!');
  console.log('⚠️  Please update the database password and other settings in .env file\n');
} else {
  console.log('✅ .env file already exists\n');
}

// Check if node_modules exists
const nodeModulesPath = path.join(__dirname, 'node_modules');
if (!fs.existsSync(nodeModulesPath)) {
  console.log('📦 Installing dependencies...');
  try {
    execSync('npm install', { stdio: 'inherit' });
    console.log('✅ Dependencies installed successfully!\n');
  } catch (error) {
    console.error('❌ Failed to install dependencies:', error.message);
    process.exit(1);
  }
} else {
  console.log('✅ Dependencies already installed\n');
}

// Check if uploads directory exists
const uploadsPath = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsPath)) {
  console.log('📁 Creating uploads directory...');
  fs.mkdirSync(uploadsPath);
  console.log('✅ Uploads directory created!\n');
} else {
  console.log('✅ Uploads directory already exists\n');
}

// Database setup instructions
console.log('🗄️  Database Setup Instructions:');
console.log('================================');
console.log('1. Make sure PostgreSQL is installed and running');
console.log('2. Create a database named "meditai_db"');
console.log('3. Update the DB_PASSWORD in your .env file');
console.log('');
console.log('PostgreSQL commands:');
console.log('  psql -U postgres');
console.log('  CREATE DATABASE meditai_db;');
console.log('  \\q');
console.log('');

// Test database connection
console.log('🔍 Testing database connection...');
try {
  require('dotenv').config();
  const { sequelize } = require('./config/database');
  
  sequelize.authenticate()
    .then(() => {
      console.log('✅ Database connection successful!');
      
      // Sync database models
      console.log('🔄 Syncing database models...');
      return sequelize.sync({ alter: true });
    })
    .then(() => {
      console.log('✅ Database models synchronized!');
      console.log('');
      console.log('🎉 Setup completed successfully!');
      console.log('');
      console.log('Next steps:');
      console.log('1. Start the server: npm run dev');
      console.log('2. Test the API: http://localhost:3000/health');
      console.log('3. Register a user: POST http://localhost:3000/api/v1/auth/signup');
      console.log('');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Database connection failed:', error.message);
      console.log('');
      console.log('Please check:');
      console.log('1. PostgreSQL is running');
      console.log('2. Database "meditai_db" exists');
      console.log('3. DB_PASSWORD in .env file is correct');
      console.log('4. PostgreSQL user has proper permissions');
      console.log('');
      process.exit(1);
    });
} catch (error) {
  console.error('❌ Setup failed:', error.message);
  process.exit(1);
} 