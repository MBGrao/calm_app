const { sequelize } = require('./config/database');
const Content = require('./models/Content');
const UserProgress = require('./models/UserProgress');
const User = require('./models/User');

async function verifySetup() {
  try {
    console.log('🔍 Verifying MeditAi Backend Setup...\n');
    
    // Test database connection
    console.log('1. Testing database connection...');
    await sequelize.authenticate();
    console.log('✅ Database connection successful\n');
    
    // Check tables
    console.log('2. Checking database tables...');
    const tables = await sequelize.showAllTables();
    console.log('📋 Available tables:', tables);
    
    // Check content table
    console.log('\n3. Checking content table...');
    const contentCount = await Content.count();
    console.log(`📊 Content records: ${contentCount}`);
    
    if (contentCount > 0) {
      const sampleContent = await Content.findOne();
      console.log('📝 Sample content:', {
        id: sampleContent.id,
        title: sampleContent.title,
        category: sampleContent.category,
        duration: sampleContent.duration
      });
    }
    
    // Check users table
    console.log('\n4. Checking users table...');
    const userCount = await User.count();
    console.log(`👥 User records: ${userCount}`);
    
    // Test content API endpoints
    console.log('\n5. Testing content queries...');
    
    // Test category query
    const meditationContent = await Content.findAll({
      where: { category: 'meditation' },
      limit: 3
    });
    console.log(`🧘 Meditation content: ${meditationContent.length} items`);
    
    // Test search query
    const searchResults = await Content.findAll({
      where: {
        title: {
          [sequelize.Op.iLike]: '%anxiety%'
        }
      },
      limit: 3
    });
    console.log(`🔍 Search results: ${searchResults.length} items`);
    
    // Test popular content
    const popularContent = await Content.findAll({
      order: [['playCount', 'DESC']],
      limit: 3
    });
    console.log(`⭐ Popular content: ${popularContent.length} items`);
    
    // Check indexes
    console.log('\n6. Checking database indexes...');
    const indexes = await sequelize.query(`
      SELECT 
        schemaname,
        tablename,
        indexname,
        indexdef
      FROM pg_indexes 
      WHERE schemaname = 'public'
      ORDER BY tablename, indexname;
    `, { type: sequelize.QueryTypes.SELECT });
    
    console.log('📈 Database indexes:');
    indexes.forEach(index => {
      console.log(`   - ${index.tablename}.${index.indexname}`);
    });
    
    // Test model associations
    console.log('\n7. Testing model associations...');
    console.log('✅ Content model:', typeof Content);
    console.log('✅ UserProgress model:', typeof UserProgress);
    console.log('✅ User model:', typeof User);
    
    console.log('\n🎉 Backend verification completed successfully!');
    console.log('\n📋 Summary:');
    console.log(`   - Database: Connected ✅`);
    console.log(`   - Content: ${contentCount} records ✅`);
    console.log(`   - Users: ${userCount} records ✅`);
    console.log(`   - Tables: ${tables.length} tables ✅`);
    console.log(`   - Indexes: ${indexes.length} indexes ✅`);
    console.log(`   - Models: All loaded ✅`);
    
    console.log('\n🚀 Backend is ready for Function 1.2.2!');
    
  } catch (error) {
    console.error('❌ Verification failed:', error);
    process.exit(1);
  } finally {
    await sequelize.close();
  }
}

// Run verification if this file is executed directly
if (require.main === module) {
  verifySetup();
}

module.exports = { verifySetup }; 