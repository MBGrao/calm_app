# MeditAi Backend API

A Node.js backend API for the MeditAi meditation app, built with Express.js and PostgreSQL.

## 🚀 Features

- **User Authentication**: Registration, login, password reset, email verification
- **JWT Token Management**: Access tokens and refresh tokens with automatic refresh
- **User Profile Management**: Profile updates, preferences, goals
- **Content Management**: Meditation content, categories, search
- **Security**: Rate limiting, input validation, password hashing
- **Database**: PostgreSQL with Sequelize ORM
- **Error Handling**: Comprehensive error handling and logging

## 📋 Prerequisites

- Node.js (v16 or higher)
- PostgreSQL (v12 or higher)
- npm or yarn

## 🛠️ Installation

1. **Clone the repository and navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env
   ```
   
   Edit `.env` file with your configuration:
   ```env
   # Server Configuration
   PORT=3000
   NODE_ENV=development

   # Database Configuration
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=meditai_db
   DB_USER=postgres
   DB_PASSWORD=your_postgres_password

   # JWT Configuration
   JWT_SECRET=your_super_secret_jwt_key_here_make_it_long_and_random
   JWT_EXPIRES_IN=7d
   JWT_REFRESH_EXPIRES_IN=30d

   # App Configuration
   APP_NAME=MeditAi
   APP_URL=http://localhost:3000
   FRONTEND_URL=http://localhost:8080
   ```

4. **Set up PostgreSQL database**
   ```sql
   -- Connect to PostgreSQL as postgres user
   psql -U postgres

   -- Create database
   CREATE DATABASE meditai_db;

   -- Create user (optional, you can use postgres user)
   CREATE USER meditai_user WITH PASSWORD 'your_password';
   GRANT ALL PRIVILEGES ON DATABASE meditai_db TO meditai_user;
   ```

5. **Run database migrations**
   ```bash
   npm run migrate
   ```

6. **Start the server**
   ```bash
   # Development mode with auto-reload
   npm run dev

   # Production mode
   npm start
   ```

## 📚 API Endpoints

### Authentication

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| POST | `/api/v1/auth/signup` | Register new user | Public |
| POST | `/api/v1/auth/signin` | Login user | Public |
| POST | `/api/v1/auth/refresh` | Refresh access token | Public |
| POST | `/api/v1/auth/logout` | Logout user | Private |
| POST | `/api/v1/auth/forgot-password` | Request password reset | Public |
| POST | `/api/v1/auth/reset-password` | Reset password | Public |
| POST | `/api/v1/auth/verify-email` | Verify email | Public |
| GET | `/api/v1/auth/me` | Get current user | Private |

### Profile Management

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/v1/profile` | Get user profile | Private |
| PUT | `/api/v1/profile` | Update user profile | Private |
| PUT | `/api/v1/profile/change-password` | Change password | Private |
| PUT | `/api/v1/profile/privacy-policy` | Accept privacy policy | Private |
| PUT | `/api/v1/profile/terms-of-service` | Accept terms of service | Private |
| PUT | `/api/v1/profile/goals` | Update user goals | Private |
| PUT | `/api/v1/profile/preferences` | Update preferences | Private |
| DELETE | `/api/v1/profile` | Delete account | Private |
| GET | `/api/v1/profile/stats` | Get user statistics | Private |

### Content

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/v1/content` | Get all content | Public |
| GET | `/api/v1/content/:id` | Get content by ID | Public |
| GET | `/api/v1/content/category/:category` | Get content by category | Public |
| GET | `/api/v1/content/search` | Search content | Public |
| GET | `/api/v1/content/recommended` | Get recommended content | Private |
| GET | `/api/v1/content/categories` | Get all categories | Public |

## 🔐 Authentication

The API uses JWT (JSON Web Tokens) for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <access_token>
```

### Token Types

- **Access Token**: Short-lived (7 days), used for API requests
- **Refresh Token**: Long-lived (30 days), used to get new access tokens

## 📝 Request Examples

### User Registration
```bash
curl -X POST http://localhost:3000/api/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123",
    "firstName": "John",
    "lastName": "Doe",
    "acceptPrivacyPolicy": true,
    "acceptTermsOfService": true
  }'
```

### User Login
```bash
curl -X POST http://localhost:3000/api/v1/auth/signin \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123"
  }'
```

### Get User Profile
```bash
curl -X GET http://localhost:3000/api/v1/profile \
  -H "Authorization: Bearer <access_token>"
```

### Update Profile
```bash
curl -X PUT http://localhost:3000/api/v1/profile \
  -H "Authorization: Bearer <access_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Jane",
    "lastName": "Smith",
    "phoneNumber": "+1234567890"
  }'
```

## 🗄️ Database Schema

### Users Table
- `id` (UUID, Primary Key)
- `email` (String, Unique)
- `password` (String, Hashed)
- `firstName` (String)
- `lastName` (String)
- `isEmailVerified` (Boolean)
- `authProvider` (Enum: email, google, facebook, apple)
- `avatar` (String, URL)
- `preferences` (JSONB)
- `goals` (Array of Strings)
- `subscriptionStatus` (Enum: free, premium, trial)
- `createdAt` (Timestamp)
- `updatedAt` (Timestamp)

### Refresh Tokens Table
- `id` (UUID, Primary Key)
- `token` (String, Unique)
- `userId` (UUID, Foreign Key)
- `expiresAt` (Timestamp)
- `isRevoked` (Boolean)
- `createdAt` (Timestamp)
- `updatedAt` (Timestamp)

## 🔧 Development

### Scripts

```bash
# Start development server
npm run dev

# Start production server
npm start

# Run tests
npm test

# Run database migrations
npm run migrate

# Seed database with sample data
npm run seed
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Server port | 3000 |
| `NODE_ENV` | Environment | development |
| `DB_HOST` | Database host | localhost |
| `DB_PORT` | Database port | 5432 |
| `DB_NAME` | Database name | meditai_db |
| `DB_USER` | Database user | postgres |
| `DB_PASSWORD` | Database password | - |
| `JWT_SECRET` | JWT secret key | - |
| `JWT_EXPIRES_IN` | Access token expiry | 7d |
| `JWT_REFRESH_EXPIRES_IN` | Refresh token expiry | 30d |

## 🚨 Security Features

- **Password Hashing**: Bcrypt with configurable rounds
- **Rate Limiting**: Prevents brute force attacks
- **Input Validation**: Joi schema validation
- **CORS**: Configured for frontend access
- **Helmet**: Security headers
- **Account Locking**: Temporary lock after failed login attempts
- **Token Revocation**: Secure logout and token management

## 📊 Error Handling

The API returns consistent error responses:

```json
{
  "error": "Error type",
  "message": "Human-readable error message"
}
```

Common HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `423` - Locked (Account locked)
- `500` - Internal Server Error

## 🧪 Testing

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage
```

## 📦 Deployment

### Production Setup

1. **Set environment variables for production**
2. **Use PM2 or similar process manager**
3. **Set up reverse proxy (Nginx)**
4. **Configure SSL certificates**
5. **Set up database backups**

### Docker Deployment

```bash
# Build Docker image
docker build -t meditai-backend .

# Run container
docker run -p 3000:3000 --env-file .env meditai-backend
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support, email support@meditai.com or create an issue in the repository. 