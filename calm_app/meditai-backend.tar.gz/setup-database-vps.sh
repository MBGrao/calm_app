#!/bin/bash

# MeditAi Database Setup Script for VPS
# VPS: 168.231.66.116

echo "🗄️ Setting up PostgreSQL database for MeditAi..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Connect to VPS and setup database
ssh root@168.231.66.116 << 'ENDSSH'
    set -e
    
    echo "📦 Installing PostgreSQL..."
    
    # Update package list
    apt update
    
    # Install PostgreSQL
    apt install -y postgresql postgresql-contrib
    
    # Start and enable PostgreSQL service
    systemctl start postgresql
    systemctl enable postgresql
    
    # Switch to postgres user
    sudo -u postgres psql << 'EOF'
        -- Create database
        CREATE DATABASE meditai_db;
        
        -- Create user
        CREATE USER meditai_user WITH PASSWORD 'meditai_prod_password_2024';
        
        -- Grant privileges
        GRANT ALL PRIVILEGES ON DATABASE meditai_db TO meditai_user;
        
        -- Connect to meditai_db
        \c meditai_db
        
        -- Grant schema privileges
        GRANT ALL ON SCHEMA public TO meditai_user;
        
        -- Exit
        \q
EOF
    
    # Configure PostgreSQL to accept connections
    echo "🔧 Configuring PostgreSQL..."
    
    # Backup original config
    cp /etc/postgresql/*/main/postgresql.conf /etc/postgresql/*/main/postgresql.conf.backup
    
    # Update postgresql.conf
    sed -i "s/#listen_addresses = 'localhost'/listen_addresses = '*'/" /etc/postgresql/*/main/postgresql.conf
    
    # Update pg_hba.conf to allow connections
    echo "host    all             all             0.0.0.0/0               md5" >> /etc/postgresql/*/main/pg_hba.conf
    
    # Restart PostgreSQL
    systemctl restart postgresql
    
    # Test connection
    echo "🧪 Testing database connection..."
    PGPASSWORD=meditai_prod_password_2024 psql -h localhost -U meditai_user -d meditai_db -c "SELECT version();"
    
    echo "✅ Database setup completed successfully!"
    echo "🗄️ Database: meditai_db"
    echo "👤 User: meditai_user"
    echo "🔑 Password: meditai_prod_password_2024"
    echo "🌐 Host: localhost:5432"
ENDSSH

print_status "Database setup completed on VPS!"
print_status "You can now deploy the backend application."
